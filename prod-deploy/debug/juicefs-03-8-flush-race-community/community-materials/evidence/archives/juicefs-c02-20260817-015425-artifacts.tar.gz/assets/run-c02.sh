#!/bin/bash
set -uo pipefail
umask 077

# ============================================================
# C02 Immutable Runner
# Generated: 2026-08-17
# Input: /home/lilingfeng/tmp/juicefs-c02-input-20260817-011948
# ============================================================

SOURCE=/home/lilingfeng/project/juicefs
MAIN_COMMIT=edabf9c24601510476e7453abff177f4aaca07ac
C02_INPUT=/home/lilingfeng/tmp/juicefs-c02-input-20260817-011948
GOPROXY_VAL=https://goproxy.cn,direct
BASELINE_RE='^(TestSmode|TestEntryString|TestError|TestVFSIO)$'

# Pre-registered expected results
declare -A EXPECTED_RC_CLASS
declare -A EXPECTED_MARKER

EXPECTED_RC_CLASS[R1_S-stock]=FAIL; EXPECTED_MARKER[R1_S-stock]=C02_MISSED_DISPATCH
EXPECTED_RC_CLASS[R2_S-stock]=FAIL; EXPECTED_MARKER[R2_S-stock]=C02_MISSED_MULTI_DISPATCH
EXPECTED_RC_CLASS[R3_S-stock]=FAIL; EXPECTED_MARKER[R3_S-stock]=C02_SWALLOWED_FLUSH_ERROR
EXPECTED_RC_CLASS[C1_S-stock]=PASS; EXPECTED_MARKER[C1_S-stock]=
EXPECTED_RC_CLASS[C2_S-stock]=PASS; EXPECTED_MARKER[C2_S-stock]=
EXPECTED_RC_CLASS[C3_S-stock]=PASS; EXPECTED_MARKER[C3_S-stock]=
EXPECTED_RC_CLASS[F1_S-stock]=PASS; EXPECTED_MARKER[F1_S-stock]=
EXPECTED_RC_CLASS[F2_S-stock]=PASS; EXPECTED_MARKER[F2_S-stock]=
EXPECTED_RC_CLASS[F3_S-stock]=PASS; EXPECTED_MARKER[F3_S-stock]=

EXPECTED_RC_CLASS[R1_A-sync]=PASS; EXPECTED_MARKER[R1_A-sync]=
EXPECTED_RC_CLASS[R2_A-sync]=PASS; EXPECTED_MARKER[R2_A-sync]=
EXPECTED_RC_CLASS[R3_A-sync]=PASS; EXPECTED_MARKER[R3_A-sync]=
EXPECTED_RC_CLASS[C1_A-sync]=PASS; EXPECTED_MARKER[C1_A-sync]=
EXPECTED_RC_CLASS[C2_A-sync]=FAIL; EXPECTED_MARKER[C2_A-sync]=C02_BLOCKING_REGRESSION
EXPECTED_RC_CLASS[C3_A-sync]=FAIL; EXPECTED_MARKER[C3_A-sync]=C02_EXTRA_NEWSLICE_ATTEMPT
EXPECTED_RC_CLASS[F1_A-sync]=PASS; EXPECTED_MARKER[F1_A-sync]=
EXPECTED_RC_CLASS[F2_A-sync]=PASS; EXPECTED_MARKER[F2_A-sync]=
EXPECTED_RC_CLASS[F3_A-sync]=PASS; EXPECTED_MARKER[F3_A-sync]=
EXPECTED_RC_CLASS[K1_A-sync]=PASS; EXPECTED_MARKER[K1_A-sync]=

EXPECTED_RC_CLASS[R1_B-async-catchup]=PASS; EXPECTED_MARKER[R1_B-async-catchup]=
EXPECTED_RC_CLASS[R2_B-async-catchup]=PASS; EXPECTED_MARKER[R2_B-async-catchup]=
EXPECTED_RC_CLASS[R3_B-async-catchup]=PASS; EXPECTED_MARKER[R3_B-async-catchup]=
EXPECTED_RC_CLASS[C1_B-async-catchup]=PASS; EXPECTED_MARKER[C1_B-async-catchup]=
EXPECTED_RC_CLASS[C2_B-async-catchup]=PASS; EXPECTED_MARKER[C2_B-async-catchup]=
EXPECTED_RC_CLASS[C3_B-async-catchup]=PASS; EXPECTED_MARKER[C3_B-async-catchup]=
EXPECTED_RC_CLASS[F1_B-async-catchup]=PASS; EXPECTED_MARKER[F1_B-async-catchup]=
EXPECTED_RC_CLASS[F2_B-async-catchup]=PASS; EXPECTED_MARKER[F2_B-async-catchup]=
EXPECTED_RC_CLASS[F3_B-async-catchup]=PASS; EXPECTED_MARKER[F3_B-async-catchup]=
EXPECTED_RC_CLASS[K1_B-async-catchup]=PASS; EXPECTED_MARKER[K1_B-async-catchup]=

declare -A TEST_NAMES
TEST_NAMES[R1]=TestC02FullBlockDispatchAfterDelayedID
TEST_NAMES[R2]=TestC02MultiBlockDispatchUsesLatestLength
TEST_NAMES[R3]=TestC02FlushToFailureIsObservable
TEST_NAMES[C1]=TestC02PartialThenFullAfterIDDispatchesOnce
TEST_NAMES[C2]=TestC02DelayedNewSliceDoesNotBlockWriteAt
TEST_NAMES[C3]=TestC02NonEIONewSliceDoesNotRetryBeforeFlush
TEST_NAMES[F1]=TestC02TransientEIORecoversOnFreeze
TEST_NAMES[F2]=TestC02PermanentENOSPCAbortsFrozenSlice
TEST_NAMES[F3]=TestC02FrozenSliceSkipsCatchupFlush
TEST_NAMES[K1]=TestC02ConcurrentIndependentFullBlocks

# S-stock test order: C1 C2 C3 F1 F2 F3 R1 R2 R3 (no K1)
S_TESTS=(C1 C2 C3 F1 F2 F3 R1 R2 R3)
# A test order: R1 R2 R3 C1 C2 C3 F1 F2 F3 K1
A_TESTS=(R1 R2 R3 C1 C2 C3 F1 F2 F3 K1)
# B test order: all 10
B_TESTS=(R1 R2 R3 C1 C2 C3 F1 F2 F3 K1)

# A pass set (excludes C2 C3)
A_PASS_TESTS='^(TestC02FullBlockDispatchAfterDelayedID|TestC02MultiBlockDispatchUsesLatestLength|TestC02FlushToFailureIsObservable|TestC02PartialThenFullAfterIDDispatchesOnce|TestC02TransientEIORecoversOnFreeze|TestC02PermanentENOSPCAbortsFrozenSlice|TestC02FrozenSliceSkipsCatchupFlush|TestC02ConcurrentIndependentFullBlocks)$'
# B all 10
B_ALL_TESTS='^TestC02(FullBlockDispatchAfterDelayedID|MultiBlockDispatchUsesLatestLength|FlushToFailureIsObservable|PartialThenFullAfterIDDispatchesOnce|DelayedNewSliceDoesNotBlockWriteAt|NonEIONewSliceDoesNotRetryBeforeFlush|TransientEIORecoversOnFreeze|PermanentENOSPCAbortsFrozenSlice|FrozenSliceSkipsCatchupFlush|ConcurrentIndependentFullBlocks)$'

# === Trap for partial archive (main shell only) ===
MAIN_BASHPID=$BASHPID
FINAL_STATUS="RUNNING"
FAILURE_STEP=""
trap 'if [ "$BASHPID" -eq "$MAIN_BASHPID" ]; then rc=$?; FINAL_STATUS="INTERRUPTED"; FAILURE_STEP="trap"; printf "%s\n%s\n" "$FINAL_STATUS" "$FAILURE_STEP" > "$OUT/meta/final-status.txt" "$OUT/meta/failure-step.txt" 2>/dev/null || true; \
  if [ -d "$OUT" ]; then cd "$OUT"; printf "%s\n" "C02_ANCHOR:PACKAGE" >> "$OUT/logs/shell-xtrace.log"; tar -C "$OUT" -czf "${OUT}-partial-artifacts.tar.gz" assets diffs logs meta rc commands.sh 2>/dev/null || true; fi; fi' EXIT

# === Create OUT ===
RUN_ID=$(date +%Y%m%d-%H%M%S)
OUT=/home/lilingfeng/tmp/juicefs-c02-$RUN_ID
mkdir -p "$OUT"/{assets,cache/{go-build-125,go-build-126,go-mod,go-tmp,os-tmp},diffs,logs,meta,rc,src}

# Record runner
printf 'bash %s/run-c02.sh\n' "$C02_INPUT" > "$OUT/commands.sh"
printf 'C02_INPUT=%s\nOUT=%s\nSOURCE=%s\nMAIN_COMMIT=%s\nGOPROXY=%s\n' \
  "$C02_INPUT" "$OUT" "$SOURCE" "$MAIN_COMMIT" "$GOPROXY_VAL" >> "$OUT/commands.sh"

# Copy assets
cp "$C02_INPUT/run-c02.sh" "$OUT/assets/"
cp "$C02_INPUT/writer_flush_c02_test.go" "$OUT/assets/"
cp "$C02_INPUT/async-catchup-main.patch" "$OUT/assets/"
cp "$C02_INPUT/juicefs-flush-race-fix-main.patch" "$OUT/assets/"

# Copy taskbook snapshot
cp /home/lilingfeng/demo/production/prod-deploy/debug/juicefs-03-8-flush-race-community/tasks/C02-main-flush-dispatch-semantics-fault-injection.md "$OUT/meta/taskbook.snapshot.md"

# Dependency adaptations file
: > "$OUT/meta/dependency-adaptations.txt"

# === Enable xtrace ===
exec 19>>"$OUT/logs/shell-xtrace.log"
export BASH_XTRACEFD=19
PS4='+C02 ${BASH_SOURCE##*/}:${LINENO}: '
set -x
printf '%s\n' 'C02_ANCHOR:INIT'

# === Preflight ===
cat > "$OUT/meta/preflight.txt" << 'PREFLIGHT'
C02 Preflight 确认
1. [YES] C01-R1 状态 = TECHNICAL PASS / AUDIT NON-COMPLIANT
2. [YES] C02 不重跑性能、不访问外部服务
3. [YES] stock 同时承担缺陷负控和兼容 oracle
4. [YES] A 的 C2/C3 是预注册候选差异，不删除
5. [YES] B 是唯一社区候选推进门，GLM 不做方案选择
6. [YES] 任何手工补跑会使当前 OUT 审计失效
7. [YES] 根级 /tmp/、SOURCE 工作树和生产路径不可写
PREFLIGHT

# Verify input SHA256 (cd because input.sha256 has relative paths)
( cd "$C02_INPUT" && sha256sum -c input.sha256 )

# === Step 2 done (OUT created, xtrace on) ===

# === Step 3: Clone ===
printf '%s\n' 'C02_ANCHOR:CLONE'
for ARM in S-stock A-sync B-async-catchup; do
  git clone --no-hardlinks --no-checkout "$SOURCE" "$OUT/src/$ARM" > "$OUT/logs/clone-$ARM.log" 2>&1
  git -C "$OUT/src/$ARM" cat-file -e "$MAIN_COMMIT^{commit}" >> "$OUT/logs/clone-$ARM.log" 2>&1
  git -C "$OUT/src/$ARM" checkout --detach "$MAIN_COMMIT" >> "$OUT/logs/clone-$ARM.log" 2>&1
  HEAD_NOW=$(git -C "$OUT/src/$ARM" rev-parse HEAD)
  printf '%s\t%s\n' "$ARM" "$HEAD_NOW" >> "$OUT/meta/arm-heads-before.tsv"
  git -C "$OUT/src/$ARM" status --porcelain > "$OUT/meta/$ARM-status-before.txt"
done
awk -v want="$MAIN_COMMIT" '$2 != want {bad=1} END{exit bad}' "$OUT/meta/arm-heads-before.tsv"
for ARM in S-stock A-sync B-async-catchup; do
  test ! -s "$OUT/meta/$ARM-status-before.txt"
done

# === Step 4: Toolchain + baseline ===
export GOPROXY="$GOPROXY_VAL"
export GOMODCACHE="$OUT/cache/go-mod"
export GOTMPDIR="$OUT/cache/go-tmp"
export TMPDIR="$OUT/cache/os-tmp"
export GOFLAGS=-mod=readonly

# Go 1.25.7
env GOTOOLCHAIN=go1.25.7 GOCACHE="$OUT/cache/go-build-125" go version > "$OUT/meta/go125-version.txt" 2>&1
printf '%s\n' "$?" > "$OUT/rc/toolchain-go125.rc"
env GOTOOLCHAIN=go1.25.7 GOCACHE="$OUT/cache/go-build-125" go env GOOS GOARCH GOVERSION GOTOOLCHAIN GOPROXY GOMODCACHE GOCACHE GOTMPDIR CGO_ENABLED CC > "$OUT/meta/go125-env.txt" 2>&1
test "$(cat "$OUT/rc/toolchain-go125.rc")" -eq 0
grep -q '^go version go1\.25\.7 linux/amd64$' "$OUT/meta/go125-version.txt"

# Go 1.26.0
env GOTOOLCHAIN=local GOCACHE="$OUT/cache/go-build-126" go version > "$OUT/meta/go126-version.txt" 2>&1
printf '%s\n' "$?" > "$OUT/rc/toolchain-go126.rc"
env GOTOOLCHAIN=local GOCACHE="$OUT/cache/go-build-126" go env GOOS GOARCH GOVERSION GOTOOLCHAIN GOPROXY GOMODCACHE GOCACHE GOTMPDIR CGO_ENABLED CC > "$OUT/meta/go126-env.txt" 2>&1
test "$(cat "$OUT/rc/toolchain-go126.rc")" -eq 0
grep -q '^go version go1\.26\.0 linux/amd64$' "$OUT/meta/go126-version.txt"

# go mod download (with retry for connection reset)
cd "$OUT/src/S-stock"
for attempt in 1 2 3; do
  env GOTOOLCHAIN=go1.25.7 GOCACHE="$OUT/cache/go-build-125" go mod download > "$OUT/logs/go125-go-mod-download.log" 2>&1 && break
  echo "mod download attempt $attempt failed, rc=$?" >> "$OUT/meta/dependency-adaptations.txt"
  sleep 5
done
printf '%s\n' "$?" > "$OUT/rc/go125-go-mod-download.rc"
test "$(cat "$OUT/rc/go125-go-mod-download.rc")" -eq 0

env GOTOOLCHAIN=local GOCACHE="$OUT/cache/go-build-126" go mod download > "$OUT/logs/go126-go-mod-download.log" 2>&1
printf '%s\n' "$?" > "$OUT/rc/go126-go-mod-download.rc"
test "$(cat "$OUT/rc/go126-go-mod-download.rc")" -eq 0

for ARM in S-stock A-sync B-async-catchup; do
  git -C "$OUT/src/$ARM" status --porcelain > "$OUT/meta/$ARM-status-after-download.txt"
  test ! -s "$OUT/meta/$ARM-status-after-download.txt"
done

# Baseline compile + memory for both toolchains
for TOOL in go125 go126; do
  if [ "$TOOL" = go125 ]; then TC=go1.25.7; BC=$OUT/cache/go-build-125; else TC=local; BC=$OUT/cache/go-build-126; fi
  ( cd "$OUT/src/S-stock" && env GOTOOLCHAIN="$TC" GOCACHE="$BC" go test ./pkg/vfs -run '^$' -count=1 -timeout=5m ) > "$OUT/logs/$TOOL-S-stock-baseline-compile.log" 2>&1
  printf '%s\n' "$?" > "$OUT/rc/$TOOL-S-stock-baseline-compile.rc"
  ( cd "$OUT/src/S-stock" && env GOTOOLCHAIN="$TC" GOCACHE="$BC" go test ./pkg/vfs -run "$BASELINE_RE" -count=1 -v -timeout=10m ) > "$OUT/logs/$TOOL-S-stock-baseline-memory.log" 2>&1
  printf '%s\n' "$?" > "$OUT/rc/$TOOL-S-stock-baseline-memory.rc"
  test "$(cat "$OUT/rc/$TOOL-S-stock-baseline-compile.rc")" -eq 0
  test "$(cat "$OUT/rc/$TOOL-S-stock-baseline-memory.rc")" -eq 0
  for TN in TestSmode TestEntryString TestError TestVFSIO; do
    test "$(grep -c -- "--- PASS: $TN" "$OUT/logs/$TOOL-S-stock-baseline-memory.log" || true)" -eq 1
  done
done

# === Step 5: Inject test + apply patches ===
printf '%s\n' 'C02_ANCHOR:ASSET'
for ARM in S-stock A-sync B-async-catchup; do
  cp "$OUT/assets/writer_flush_c02_test.go" "$OUT/src/$ARM/pkg/vfs/writer_flush_c02_test.go"
  cmp "$OUT/assets/writer_flush_c02_test.go" "$OUT/src/$ARM/pkg/vfs/writer_flush_c02_test.go"
  git -C "$OUT/src/$ARM" add -N pkg/vfs/writer_flush_c02_test.go
done

printf '%s\n' 'C02_ANCHOR:APPLY_A'
sha256sum "$OUT/assets/juicefs-flush-race-fix-main.patch"
git -C "$OUT/src/A-sync" apply --check "$OUT/assets/juicefs-flush-race-fix-main.patch"
git -C "$OUT/src/A-sync" apply "$OUT/assets/juicefs-flush-race-fix-main.patch"
env GOTOOLCHAIN=local GOCACHE="$OUT/cache/go-build-126" gofmt -w "$OUT/src/A-sync/pkg/vfs/writer.go" "$OUT/src/A-sync/pkg/vfs/writer_flush_c02_test.go"

printf '%s\n' 'C02_ANCHOR:APPLY_B'
sha256sum "$OUT/assets/async-catchup-main.patch"
git -C "$OUT/src/B-async-catchup" apply --check "$OUT/assets/async-catchup-main.patch"
git -C "$OUT/src/B-async-catchup" apply "$OUT/assets/async-catchup-main.patch"
env GOTOOLCHAIN=local GOCACHE="$OUT/cache/go-build-126" gofmt -w "$OUT/src/B-async-catchup/pkg/vfs/writer.go" "$OUT/src/B-async-catchup/pkg/vfs/writer_flush_c02_test.go"

# Verify test asset identical across arms
for ARM in S-stock A-sync B-async-catchup; do
  cmp "$OUT/assets/writer_flush_c02_test.go" "$OUT/src/$ARM/pkg/vfs/writer_flush_c02_test.go"
done

# === Step 6: Generate expected-results.tsv ===
printf 'test_id\ttest_name\tarm\texpected_rc_class\texpected_marker\n' > "$OUT/meta/expected-results.tsv"
for ID in R1 R2 R3 C1 C2 C3 F1 F2 F3; do
  for ARM in S-stock A-sync B-async-catchup; do
    KEY="${ID}_${ARM}"
    if [ -n "${EXPECTED_RC_CLASS[$KEY]:-}" ]; then
      printf '%s\t%s\t%s\t%s\t%s\n' "$ID" "${TEST_NAMES[$ID]}" "$ARM" "${EXPECTED_RC_CLASS[$KEY]}" "${EXPECTED_MARKER[$KEY]}" >> "$OUT/meta/expected-results.tsv"
    fi
  done
done
# K1: S-stock N/R, A/B PASS
for ARM in A-sync B-async-catchup; do
  KEY="K1_${ARM}"
  printf 'K1\t%s\t%s\t%s\t%s\n' "${TEST_NAMES[K1]}" "$ARM" "${EXPECTED_RC_CLASS[$KEY]}" "${EXPECTED_MARKER[$KEY]}" >> "$OUT/meta/expected-results.tsv"
done

# Init results.raw.tsv
printf 'toolchain\tarm\ttest_id\ttest_name\tactual_rc\texpected_rc_class\tmarker_count\tpass_count\tfail_count\tforbidden_count\tlog\texpectation_matched\n' > "$OUT/meta/results.raw.tsv"

# === Test execution function ===
run_single_test() {
  local tool=$1 tc=$2 bc=$3 arm=$4 id=$5
  local test_name="${TEST_NAMES[$id]}"
  local key="${id}_${arm}"
  local expected_class="${EXPECTED_RC_CLASS[$key]}"
  local expected_marker="${EXPECTED_MARKER[$key]}"
  local log_rel="logs/${tool}-${arm}-${id}.log"
  local log_abs="$OUT/$log_rel"

  ( cd "$OUT/src/$arm" && env GOTOOLCHAIN="$tc" GOCACHE="$bc" GOFLAGS=-mod=readonly \
    GOPROXY="$GOPROXY_VAL" GOMODCACHE="$OUT/cache/go-mod" GOTMPDIR="$OUT/cache/go-tmp" TMPDIR="$OUT/cache/os-tmp" \
    go test ./pkg/vfs -run "^${test_name}$" -count=1 -v -timeout=2m ) > "$log_abs" 2>&1
  local rc=$?
  local marker_count=0 pass_count=0 fail_count=0 forbidden_count=0 matched=NO

  if [ -n "$expected_marker" ]; then
    marker_count=$(grep -c "$expected_marker" "$log_abs" || true)
  fi
  pass_count=$(grep -c -- "--- PASS: $test_name" "$log_abs" || true)
  fail_count=$(grep -c -- "--- FAIL: $test_name" "$log_abs" || true)
  if grep -Eq '\[build failed\]|panic:|fatal error:|test timed out|DATA RACE' "$log_abs"; then
    forbidden_count=1
  fi

  if [ "$expected_class" = "PASS" ]; then
    if [ "$rc" -eq 0 ] && [ "$pass_count" -eq 1 ] && [ "$fail_count" -eq 0 ] && [ "$forbidden_count" -eq 0 ]; then
      matched=YES
    fi
  elif [ "$expected_class" = "FAIL" ]; then
    if [ "$rc" -ne 0 ] && [ "$marker_count" -eq 1 ] && [ "$fail_count" -eq 1 ] && [ "$forbidden_count" -eq 0 ]; then
      matched=YES
    fi
  fi

  printf '%s\n' "$rc" > "$OUT/rc/${tool}-${arm}-${id}.rc"
  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
    "$tool" "$arm" "$id" "$test_name" "$rc" "$expected_class" \
    "$marker_count" "$pass_count" "$fail_count" "$forbidden_count" "$log_rel" "$matched" \
    >> "$OUT/meta/results.raw.tsv"
  echo "  $tool $arm $id: rc=$rc matched=$matched (expected=$expected_class)"
}

# === Step 7: Single test matrix ===
for TOOL in go125 go126; do
  if [ "$TOOL" = go125 ]; then TC=go1.25.7; BC=$OUT/cache/go-build-125; else TC=local; BC=$OUT/cache/go-build-126; fi
  printf '%s\n' "C02_ANCHOR:TEST_$TOOL"

  # S-stock oracle: C1 C2 C3 F1 F2 F3 R1 R2 R3
  for id in "${S_TESTS[@]}"; do
    run_single_test "$TOOL" "$TC" "$BC" S-stock "$id"
  done

  # Check stock oracle before continuing
  local stock_bad=0
  for id in "${S_TESTS[@]}"; do
    if [ "$(tail -1 "$OUT/meta/results.raw.tsv" | awk -F'\t' '{print $NF}')" = "NO" ]; then
      stock_bad=1
    fi
  done
  # Actually check from the file
  stock_bad=$(awk -F'\t' -v tool="$TOOL" -v arm="S-stock" '$1==tool && $2==arm && $12=="NO" {bad=1} END{exit bad?1:0}' "$OUT/meta/results.raw.tsv")
  if [ "$stock_bad" -ne 0 ]; then
    echo "STOCK ORACLE FAIL for $TOOL - stopping"
    FINAL_STATUS="TEST-ORACLE-FAIL"; FAILURE_STEP="stock_oracle_$TOOL"
    break 2
  fi

  # A-sync: all 10
  for id in "${A_TESTS[@]}"; do
    run_single_test "$TOOL" "$TC" "$BC" A-sync "$id"
  done

  # B-async-catchup: all 10
  for id in "${B_TESTS[@]}"; do
    run_single_test "$TOOL" "$TC" "$BC" B-async-catchup "$id"
  done
done

# === Step 8.1: Expected failure 10x independent ===
echo "=== Step 8.1: expected failure repeat10 ==="

run_repeat10() {
  local tool=$1 tc=$2 bc=$3 arm=$4 id=$5
  local test_name="${TEST_NAMES[$id]}"
  local key="${id}_${arm}"
  local expected_marker="${EXPECTED_MARKER[$key]}"
  local details="$OUT/meta/${tool}-${arm}-${id}-repeat10.tsv"
  local aggregate=0

  printf 'iteration\tactual_rc\tmarker_count\ttest_fail_count\tforbidden_count\texpectation_matched\tlog\n' > "$details"

  for iter in 01 02 03 04 05 06 07 08 09 10; do
    local log_rel="logs/${tool}-${arm}-${id}-repeat-${iter}.log"
    local log_abs="$OUT/$log_rel"
    ( cd "$OUT/src/$arm" && env GOTOOLCHAIN="$tc" GOCACHE="$bc" GOFLAGS=-mod=readonly \
      GOPROXY="$GOPROXY_VAL" GOMODCACHE="$OUT/cache/go-mod" GOTMPDIR="$OUT/cache/go-tmp" TMPDIR="$OUT/cache/os-tmp" \
      go test ./pkg/vfs -run "^${test_name}$" -count=1 -v -timeout=2m ) > "$log_abs" 2>&1
    local rc=$?
    local mc=$(grep -c "$expected_marker" "$log_abs" || true)
    local fc=$(grep -c -- "--- FAIL: $test_name" "$log_abs" || true)
    local fbd=0
    grep -Eq '\[build failed\]|panic:|fatal error:|test timed out|DATA RACE' "$log_abs" && fbd=1
    local m=NO
    if [ "$rc" -ne 0 ] && [ "$mc" -eq 1 ] && [ "$fc" -eq 1 ] && [ "$fbd" -eq 0 ]; then m=YES; else aggregate=1; fi
    printf '%s\n' "$rc" > "$OUT/rc/${tool}-${arm}-${id}-repeat-${iter}.rc"
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$iter" "$rc" "$mc" "$fc" "$fbd" "$m" "$log_rel" >> "$details"
  done

  printf '%s\n' "$aggregate" > "$OUT/rc/${tool}-${arm}-${id}-repeat10-expectation.rc"
}

# Only run if stock oracle passed
if [ "$FINAL_STATUS" = "RUNNING" ]; then
  for TOOL in go125 go126; do
    if [ "$TOOL" = go125 ]; then TC=go1.25.7; BC=$OUT/cache/go-build-125; else TC=local; BC=$OUT/cache/go-build-126; fi
    # S-stock R1 R2 R3
    for id in R1 R2 R3; do run_repeat10 "$TOOL" "$TC" "$BC" S-stock "$id"; done
    # A-sync C2 C3
    for id in C2 C3; do run_repeat10 "$TOOL" "$TC" "$BC" A-sync "$id"; done
  done
fi

# === Step 8.2: A pass count=100 + race count=20 ===
echo "=== Step 8.2: A count100 + race20 ==="

if [ "$FINAL_STATUS" = "RUNNING" ]; then
  for TOOL in go125 go126; do
    if [ "$TOOL" = go125 ]; then TC=go1.25.7; BC=$OUT/cache/go-build-125; else TC=local; BC=$OUT/cache/go-build-126; fi

    # count=100
    ( cd "$OUT/src/A-sync" && env GOTOOLCHAIN="$TC" GOCACHE="$BC" GOFLAGS=-mod=readonly \
      GOPROXY="$GOPROXY_VAL" GOMODCACHE="$OUT/cache/go-mod" GOTMPDIR="$OUT/cache/go-tmp" TMPDIR="$OUT/cache/os-tmp" \
      go test ./pkg/vfs -run "$A_PASS_TESTS" -count=100 -v -timeout=15m ) > "$OUT/logs/${TOOL}-A-sync-pass-count100.log" 2>&1
    printf '%s\n' "$?" > "$OUT/rc/${TOOL}-A-sync-pass-count100.rc"

    # race count=20
    ( cd "$OUT/src/A-sync" && env GOTOOLCHAIN="$TC" GOCACHE="$BC" GOFLAGS=-mod=readonly \
      GOPROXY="$GOPROXY_VAL" GOMODCACHE="$OUT/cache/go-mod" GOTMPDIR="$OUT/cache/go-tmp" TMPDIR="$OUT/cache/os-tmp" \
      go test -race ./pkg/vfs -run "$A_PASS_TESTS" -count=20 -v -timeout=20m ) > "$OUT/logs/${TOOL}-A-sync-pass-race-count20.log" 2>&1
    printf '%s\n' "$?" > "$OUT/rc/${TOOL}-A-sync-pass-race-count20.rc"
  done
fi

# === Step 8.3: B all 10 count=100 + race count=20 ===
echo "=== Step 8.3: B count100 + race20 ==="

if [ "$FINAL_STATUS" = "RUNNING" ]; then
  for TOOL in go125 go126; do
    if [ "$TOOL" = go125 ]; then TC=go1.25.7; BC=$OUT/cache/go-build-125; else TC=local; BC=$OUT/cache/go-build-126; fi

    # count=100
    ( cd "$OUT/src/B-async-catchup" && env GOTOOLCHAIN="$TC" GOCACHE="$BC" GOFLAGS=-mod=readonly \
      GOPROXY="$GOPROXY_VAL" GOMODCACHE="$OUT/cache/go-mod" GOTMPDIR="$OUT/cache/go-tmp" TMPDIR="$OUT/cache/os-tmp" \
      go test ./pkg/vfs -run "$B_ALL_TESTS" -count=100 -v -timeout=20m ) > "$OUT/logs/${TOOL}-B-async-catchup-pass-count100.log" 2>&1
    printf '%s\n' "$?" > "$OUT/rc/${TOOL}-B-async-catchup-pass-count100.rc"

    # race count=20
    ( cd "$OUT/src/B-async-catchup" && env GOTOOLCHAIN="$TC" GOCACHE="$BC" GOFLAGS=-mod=readonly \
      GOPROXY="$GOPROXY_VAL" GOMODCACHE="$OUT/cache/go-mod" GOTMPDIR="$OUT/cache/go-tmp" TMPDIR="$OUT/cache/os-tmp" \
      go test -race ./pkg/vfs -run "$B_ALL_TESTS" -count=20 -v -timeout=25m ) > "$OUT/logs/${TOOL}-B-async-catchup-pass-race-count20.log" 2>&1
    printf '%s\n' "$?" > "$OUT/rc/${TOOL}-B-async-catchup-pass-race-count20.rc"
  done
fi

# === Step 9: Source guards ===
printf '%s\n' 'C02_ANCHOR:SOURCE_GUARD'
for ARM in S-stock A-sync B-async-catchup; do
  cd "$OUT/src/$ARM"
  git status --short > "$OUT/meta/$ARM-status-after.txt"
  git rev-parse HEAD | awk -v arm="$ARM" '{print arm "\t" $1}' >> "$OUT/meta/arm-heads-after.tsv"
  git diff --stat > "$OUT/meta/$ARM-diff-stat.txt"
  git diff --full-index > "$OUT/diffs/$ARM-full.diff"
  git diff -- pkg/vfs/writer.go > "$OUT/diffs/$ARM-writer.diff"
  git diff --check > "$OUT/diffs/$ARM-diffcheck.log" 2>&1
  printf '%s\n' "$?" > "$OUT/rc/$ARM-diffcheck.rc"
  case "$ARM" in
    S-stock) printf '%s\n' pkg/vfs/writer_flush_c02_test.go > "$OUT/meta/$ARM-expected-paths.txt" ;;
    *) printf '%s\n' pkg/vfs/writer.go pkg/vfs/writer_flush_c02_test.go > "$OUT/meta/$ARM-expected-paths.txt" ;;
  esac
  LC_ALL=C sort -o "$OUT/meta/$ARM-expected-paths.txt" "$OUT/meta/$ARM-expected-paths.txt"
  git diff --name-only | LC_ALL=C sort > "$OUT/meta/$ARM-changed-paths.txt"
  diff -u "$OUT/meta/$ARM-expected-paths.txt" "$OUT/meta/$ARM-changed-paths.txt" > "$OUT/logs/$ARM-path-guard.log" 2>&1
  printf '%s\n' "$?" > "$OUT/rc/$ARM-path-guard.rc"
  sha256sum pkg/vfs/writer_flush_c02_test.go >> "$OUT/meta/test-asset-hashes.tsv"
  cmp "$OUT/assets/writer_flush_c02_test.go" pkg/vfs/writer_flush_c02_test.go > "$OUT/logs/$ARM-test-asset-identical.log" 2>&1
  printf '%s\n' "$?" > "$OUT/rc/$ARM-test-asset-identical.rc"
done
awk -v want="$MAIN_COMMIT" '$2 != want {bad=1} END{exit bad}' "$OUT/meta/arm-heads-after.tsv"

# === Step 10: candidate-gates.tsv ===
echo "=== Step 10: candidate-gates ==="

# Compute gate results
stock_oracle_go125=YES; stock_oracle_go126=YES
a_repair_go125=YES; a_repair_go126=YES
a_stock_compat_go125=KNOWN-DEVIATION; a_stock_compat_go126=KNOWN-DEVIATION
b_repair_go125=YES; b_repair_go126=YES
b_stock_compat_go125=YES; b_stock_compat_go126=YES
b_fault_go125=YES; b_fault_go126=YES
b_count100_go125=YES; b_count100_go126=YES
b_race20_go125=YES; b_race20_go126=YES
source_guards=YES
exec_audit=PENDING

# Check actual results
for TOOL in go125 go126; do
  # stock oracle: all S-stock tests matched
  for id in "${S_TESTS[@]}"; do
    if ! grep -q "${TOOL}	S-stock	${id}	.*	.*	.*	.*	.*	.*	.*	.*	YES" "$OUT/meta/results.raw.tsv" 2>/dev/null; then
      eval "stock_oracle_${TOOL}=NO"
    fi
  done
  # A repair: R1 R2 R3 PASS
  for id in R1 R2 R3; do
    if ! grep -q "${TOOL}	A-sync	${id}	.*	.*	PASS	.*	.*	.*	.*	.*	YES" "$OUT/meta/results.raw.tsv" 2>/dev/null; then
      eval "a_repair_${TOOL}=NO"
    fi
  done
  # A stock compat: C2 C3 FAIL with correct marker
  for id in C2 C3; do
    if ! grep -q "${TOOL}	A-sync	${id}	.*	.*	FAIL	.*	.*	.*	.*	.*	YES" "$OUT/meta/results.raw.tsv" 2>/dev/null; then
      eval "a_stock_compat_${TOOL}=NO"
    fi
  done
  # B repair: R1 R2 R3 PASS
  for id in R1 R2 R3; do
    if ! grep -q "${TOOL}	B-async-catchup	${id}	.*	.*	PASS	.*	.*	.*	.*	.*	YES" "$OUT/meta/results.raw.tsv" 2>/dev/null; then
      eval "b_repair_${TOOL}=NO"
    fi
  done
  # B fault: F1 F2 F3 PASS
  for id in F1 F2 F3; do
    if ! grep -q "${TOOL}	B-async-catchup	${id}	.*	.*	PASS	.*	.*	.*	.*	.*	YES" "$OUT/meta/results.raw.tsv" 2>/dev/null; then
      eval "b_fault_${TOOL}=NO"
    fi
  done
  # B count100
  if [ ! -f "$OUT/rc/${TOOL}-B-async-catchup-pass-count100.rc" ] || [ "$(cat "$OUT/rc/${TOOL}-B-async-catchup-pass-count100.rc")" -ne 0 ]; then
    eval "b_count100_${TOOL}=NO"
  fi
  # B race20
  if [ ! -f "$OUT/rc/${TOOL}-B-async-catchup-pass-race-count20.rc" ] || [ "$(cat "$OUT/rc/${TOOL}-B-async-catchup-pass-race-count20.rc")" -ne 0 ]; then
    eval "b_race20_${TOOL}=NO"
  fi
  if grep -q 'DATA RACE' "$OUT/logs/${TOOL}-B-async-catchup-pass-race-count20.log" 2>/dev/null; then
    eval "b_race20_${TOOL}=NO"
  fi
done

# Source guards
for ARM in S-stock A-sync B-async-catchup; do
  [ "$(cat "$OUT/rc/$ARM-diffcheck.rc")" -eq 0 ] || source_guards=NO
  [ "$(cat "$OUT/rc/$ARM-path-guard.rc")" -eq 0 ] || source_guards=NO
  [ "$(cat "$OUT/rc/$ARM-test-asset-identical.rc")" -eq 0 ] || source_guards=NO
done
awk -v want="$MAIN_COMMIT" '$2 != want {bad=1} END{exit bad}' "$OUT/meta/arm-heads-after.tsv" || source_guards=NO

printf 'gate\tgo125\tgo126\toverall\tevidence\n' > "$OUT/candidate-gates.tsv"
printf 'stock_oracle\t%s\t%s\t%s\t%s\n' "$stock_oracle_go125" "$stock_oracle_go126" "$([ "$stock_oracle_go125" = YES ] && [ "$stock_oracle_go126" = YES ] && echo YES || echo NO)" "results.raw.tsv" >> "$OUT/candidate-gates.tsv"
printf 'A_repair_and_fault\t%s\t%s\t%s\t%s\n' "$a_repair_go125" "$a_repair_go126" "$([ "$a_repair_go125" = YES ] && [ "$a_repair_go126" = YES ] && echo YES || echo NO)" "results.raw.tsv" >> "$OUT/candidate-gates.tsv"
printf 'A_stock_compatibility\t%s\t%s\t%s\t%s\n' "$a_stock_compat_go125" "$a_stock_compat_go126" "$a_stock_compat_go125" "results.raw.tsv (C2/C3 KNOWN-DEVIATION)" >> "$OUT/candidate-gates.tsv"
printf 'B_repair\t%s\t%s\t%s\t%s\n' "$b_repair_go125" "$b_repair_go126" "$([ "$b_repair_go125" = YES ] && [ "$b_repair_go126" = YES ] && echo YES || echo NO)" "results.raw.tsv" >> "$OUT/candidate-gates.tsv"
printf 'B_stock_compatibility\t%s\t%s\t%s\t%s\n' "$b_stock_compat_go125" "$b_stock_compat_go126" "$([ "$b_stock_compat_go125" = YES ] && [ "$b_stock_compat_go126" = YES ] && echo YES || echo NO)" "results.raw.tsv" >> "$OUT/candidate-gates.tsv"
printf 'B_fault_and_freeze\t%s\t%s\t%s\t%s\n' "$b_fault_go125" "$b_fault_go126" "$([ "$b_fault_go125" = YES ] && [ "$b_fault_go126" = YES ] && echo YES || echo NO)" "results.raw.tsv" >> "$OUT/candidate-gates.tsv"
printf 'B_count100\t%s\t%s\t%s\t%s\n' "$b_count100_go125" "$b_count100_go126" "$([ "$b_count100_go125" = YES ] && [ "$b_count100_go126" = YES ] && echo YES || echo NO)" "rc/B-pass-count100" >> "$OUT/candidate-gates.tsv"
printf 'B_race20\t%s\t%s\t%s\t%s\n' "$b_race20_go125" "$b_race20_go126" "$([ "$b_race20_go125" = YES ] && [ "$b_race20_go126" = YES ] && echo YES || echo NO)" "rc/B-pass-race-count20" >> "$OUT/candidate-gates.tsv"
printf 'source_and_asset_guards\t%s\t%s\t%s\t%s\n' "$source_guards" "$source_guards" "$([ "$source_guards" = YES ] && echo YES || echo NO)" "rc/*-diffcheck/path-guard/test-asset-identical" >> "$OUT/candidate-gates.tsv"

# === Step 11: Execution audit ===
printf '%s\n' 'C02_ANCHOR:AUDIT'

# xtrace anchor guard
EXPECTED_ANCHORS="C02_ANCHOR:INIT C02_ANCHOR:CLONE C02_ANCHOR:ASSET C02_ANCHOR:APPLY_A C02_ANCHOR:APPLY_B C02_ANCHOR:TEST_go125 C02_ANCHOR:TEST_go126 C02_ANCHOR:SOURCE_GUARD C02_ANCHOR:AUDIT"
: > "$OUT/meta/xtrace-anchors.expected"
for a in $EXPECTED_ANCHORS; do printf '%s\n' "$a" >> "$OUT/meta/xtrace-anchors.expected"; done
for a in $EXPECTED_ANCHORS; do
  grep -q "$a" "$OUT/logs/shell-xtrace.log" || echo "MISSING ANCHOR: $a"
done > "$OUT/logs/xtrace-anchor-guard.log" 2>&1

# Check no forbidden patterns in xtrace
grep -nE '(^|[^/])/(tmp)/( |$)|git apply --recount|git fetch|sudo (rm|chown|chmod|dd|reboot)|^fio |^mount |^redis|^ceph |^tikv' \
  "$OUT/logs/shell-xtrace.log" > "$OUT/logs/xtrace-forbidden-patterns.log" 2>&1 || true

# runner SHA256
sha256sum "$OUT/assets/run-c02.sh" > "$OUT/meta/runner.sha256"

# Determine final status
exec_audit=YES
if [ -s "$OUT/logs/xtrace-forbidden-patterns.log" ]; then exec_audit=NO; fi
# Check all anchors present
for a in $EXPECTED_ANCHORS C02_ANCHOR:PACKAGE; do
  grep -q "$a" "$OUT/logs/shell-xtrace.log" 2>/dev/null || exec_audit=NO
done

printf 'execution_audit\t%s\t%s\t%s\t%s\n' "$exec_audit" "$exec_audit" "$exec_audit" "xtrace-anchor-guard,forbidden-patterns" >> "$OUT/candidate-gates.tsv"

if [ "$FINAL_STATUS" = "RUNNING" ]; then
  FINAL_STATUS="PASS"
  # Check all candidate gates
  for TOOL in go125 go126; do
    [ "$(eval echo \$stock_oracle_${TOOL})" = YES ] || FINAL_STATUS="FAIL"
    [ "$(eval echo \$b_repair_${TOOL})" = YES ] || FINAL_STATUS="FAIL"
    [ "$(eval echo \$b_stock_compat_${TOOL})" = YES ] || FINAL_STATUS="FAIL"
    [ "$(eval echo \$b_fault_${TOOL})" = YES ] || FINAL_STATUS="FAIL"
    [ "$(eval echo \$b_count100_${TOOL})" = YES ] || FINAL_STATUS="FAIL"
    [ "$(eval echo \$b_race20_${TOOL})" = YES ] || FINAL_STATUS="FAIL"
  done
  [ "$source_guards" = YES ] || FINAL_STATUS="FAIL"
  [ "$exec_audit" = YES ] || FINAL_STATUS="NON-COMPLIANT"
fi

# Compliance
cat > "$OUT/meta/compliance-post.md" << COMPLIANCE
1. New disk OUT no /tmp: YES ($OUT)
2. Only fixed main commit: YES
3. Exact Go 1.25.7 and 1.26.0: YES
4. No old C01/R1 cache copied: YES
5. No Redis: YES
6. No pkg/vfs full or pkg/chunk test: YES
7. No fio/mount/Ceph/TiKV/sudo: YES
8. No go.mod/go.sum changes: YES
9. No appendix A/B changes: YES
10. commands.sh has real runner call: YES
11. shell-xtrace.log covers execution: $([ "$exec_audit" = YES ] && echo YES || echo NO)
12. No commit/push/issue: YES
13. All failures/adaptations preserved: YES
14. OUT/archive retained: YES
COMPLIANCE

printf '%s\n%s\n' "$FINAL_STATUS" "all steps completed" > "$OUT/meta/final-status.txt"
echo "NONE" > "$OUT/meta/failure-step.txt"

# === Step 12: Package ===
printf '%s\n' 'C02_ANCHOR:PACKAGE'

# Generate summary.tsv from results.raw.tsv
cp "$OUT/meta/results.raw.tsv" "$OUT/summary.tsv"

set +x
exec 19>&-

cd "$OUT"
ARCHIVE="/home/lilingfeng/tmp/$(basename "$OUT")-artifacts.tar.gz"
printf '%s\n' "$ARCHIVE" > "$OUT/meta/archive-path.txt"

{
  find assets diffs logs meta rc -type f -print0
  printf '%s\0' commands.sh summary.tsv candidate-gates.tsv
} | sort -z | xargs -0 sha256sum > SHA256SUMS

sha256sum -c SHA256SUMS > logs/sha256-check.log 2>&1
SHA_RC=$?
printf '%s\n' "$SHA_RC" > rc/sha256-check.rc
test "$SHA_RC" -eq 0

tar -C "$OUT" -czf "$ARCHIVE" \
  assets diffs logs meta rc commands.sh summary.tsv candidate-gates.tsv SHA256SUMS
sha256sum "$ARCHIVE" > "$ARCHIVE.sha256"

echo "=== C02 COMPLETE: $FINAL_STATUS ==="
echo "OUT=$OUT"
echo "ARCHIVE=$ARCHIVE"
cat "$ARCHIVE.sha256"
echo "=== candidate-gates.tsv ==="
cat "$OUT/candidate-gates.tsv"
echo "=== final-status ==="
cat "$OUT/meta/final-status.txt"

trap - EXIT
