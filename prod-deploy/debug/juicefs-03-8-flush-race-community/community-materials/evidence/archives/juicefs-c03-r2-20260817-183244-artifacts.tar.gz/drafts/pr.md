# PR Title
vfs: dispatch complete blocks after preparing slice ID

# PR Body
## What does this PR do?
Dispatch complete blocks that were written before an asynchronously allocated slice ID became available.

## Why is this needed?
The first write to a new slice can fill a complete block while `s.id` is still zero. The write path then skips `FlushTo`, and the existing ID-ready path only calls `SetID`.

## Tests
- Deterministic in-memory tests for full, partial, and error paths
- Full pkg/vfs test suite with Redis
- golangci-lint, go vet, go mod tidy
- Linux and lite builds

GitHub Actions has not yet run.
