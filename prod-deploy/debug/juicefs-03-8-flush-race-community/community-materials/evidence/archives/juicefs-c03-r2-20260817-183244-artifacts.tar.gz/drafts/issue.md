# Issue Title
VFS may miss dispatching a full block when the slice ID is prepared asynchronously

# Issue Body
**What happened**
When a write creates a new slice, `prepareID` runs asynchronously. If the first write fills at least one block before the slice ID is ready, `sliceWriter.write` skips `FlushTo` because `s.id == 0`. When the ID later becomes ready, the current code assigns it to the chunk writer but does not revisit the missed dispatch.

**What was expected**
After the slice ID becomes available, a non-frozen slice that already contains at least one complete block should dispatch those complete blocks exactly once. A partial or frozen slice should retain its existing behavior.

**Minimal reproduction**
The attached in-memory unit test delays `NewSlice`, writes one complete block, then releases the ID allocation. It fails on stock and passes with the proposed catch-up logic.

**Environment**
- JuiceFS commit: (to be filled with frozen commit)
- Go: 1.25.7, 1.26.0
- OS/arch: linux/amd64

GitHub Actions has not yet run.
