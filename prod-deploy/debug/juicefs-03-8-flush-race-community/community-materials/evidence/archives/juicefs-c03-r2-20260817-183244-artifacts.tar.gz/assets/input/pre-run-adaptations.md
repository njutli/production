C03: lint=PENDING but final status was PASS-B-PR-READY-LOCAL
C03: gate omission (several gates hardcoded YES)
C03: anchor self-match (grep xtrace matched check command)
C03: two incomplete old OUTs (082905, 084643 have only cache remnants)
C03: runner in-place modification without new OUT
C03: missing deliverables (Redis inspect/log/destroy, build version/hash, Q singles, GitHub headers)

C03-R1 attempt 1 (input 111907, OUT 112439):
  FAILED - set -e inside run_go_test caused global errexit on return non-zero for expected FAIL test U1
  Runner SHA: 5499d50a2884d287e6a64202743e9fcbef962338698528c214df122864a13b69
  Fix: removed set -e from inside run_go_test

C03-R1 attempt 2 (input 131459, OUT 131615):
  22/24 gate YES, 2 NO due to runner bugs
  - B_gofmt_diff_license NO: license check head -1 only gets "/*", "JuiceFS" on line 2
  - execution_audit NO: anchor cmp executed BEFORE PACKAGE anchor recorded (11 vs 12 lines)
  Runner SHA: 206cb3390a85f6fad4a8d4cfb0e8a25fff7b72249ce5865f8b36f50657ea8feb

C03-R1 attempt 3 (input 140321, OUT 140452):
  24/24 gate YES, PASS-B-PR-READY-LOCAL
  Runner SHA: 12c9101bda8914d22f2595eb270699413aea73d881e4c65b19407aa63d9266df
  But Codex audit found 12 defects (see C03-R2 taskbook §0.3):
    1. runner hardcoded attempt 1 input path; archived wrong runner
    2. commands.sh/runner SHA pointed to wrong attempt
    3. input contained runtime PID/stdout files
    4. gate only checked rc, not precise PASS counts
    5. || true corrupted rc capture
    6. lint/Redis gates incomplete
    7. no SOURCE/history before/after
    8. archive manifest mismatch
    9. set -e corrupted sha256 check rc
    10. adaptations only said "runner started"
    11. required_members only checked 3 files
    12. search success != no duplicate

C03-R2 design fixes:
  - launcher/runner split, dynamic self-localization via BASH_SOURCE
  - 15-file input with strict file list, no runtime files
  - 4 result TSVs with per-test run/pass counts
  - if/else rc capture pattern (no || true)
  - Redis 14-step lifecycle TSV
  - lint 8 sub-checks
  - protected-paths before/after snapshot
  - input start/end double-check
  - gate single-resolution model
  - archive self-verification (extract + re-check)
  - 10-item integrity sidecar
  - 13 anchors (added PROTECT_SNAPSHOT)

C03-R2 pre-run: GOPROXY=goproxy.cn, Go 1.25.7 via GOTOOLCHAIN, go mod download may retry
C03-R2 pre-run: golangci-lint v2.6 to be installed to $OUT/tools/bin
C03-R2 pre-run: Docker redis:7.2-alpine may need pull

C03-R2 attempt 1 (input 151249, OUT 151942):
  FAILED - find|head pipeline SIGPIPE under set -o pipefail caused script exit during PROTECT_SNAPSHOT
  Runner SHA: (see input.sha256 of 151249)
  Fix: wrapped find|head with set +o pipefail/set -o pipefail and added -maxdepth 3

C03-R2 attempt 2 (this input 152058):
  Same runner as attempt 1 with find|head pipefail fix

C03-R2 attempt 1 (input 151249): FAILED - find|head SIGPIPE under pipefail
C03-R2 attempt 2 (input 152058): FAILED - 'local' keyword outside function (line 257)
C03-R2 attempt 3 (input 161900): FAILED - sed replaced 'local rc' with bare 'rc' (command not found)
C03-R2 attempt 4 (this input 162331): deleted bare 'local rc'/'local vfs_rc' lines, removed 'local ' from mc/fc/bad assignments

C03-R2 attempt 1 (input 151249): FAILED - find|head SIGPIPE under pipefail
C03-R2 attempt 2 (input 152058): FAILED - 'local' keyword outside function (line 257)
C03-R2 attempt 3 (input 161900): FAILED - sed replaced 'local rc' with bare 'rc' (command not found)
C03-R2 attempt 4 (input 162331): FAILED - grep -c || echo 0 produces "0\n0" breaking TSV rows (3 NO gates); protected paths snapshot includes new OUT dir (1 NO gate)
C03-R2 attempt 5 (this input): 
  Fix 1 (from attempt 1): find|head wrapped with set +o pipefail + -maxdepth 3
  Fix 2 (from attempt 2): deleted 'local rc'/'local vfs_rc' lines, removed 'local ' from mc/fc/bad
  Fix 3 (new): grep -c || echo 0 → grep -c || true (grep already outputs count; || true just suppresses exit code)
  Fix 4 (new): protected paths find excludes juicefs-c03-r2-* and juicefs-c03-r2-verify-* dirs

C03-R2 attempt 1 (input 151249): FAILED - find|head SIGPIPE under pipefail
C03-R2 attempt 2 (input 152058): FAILED - 'local' keyword outside function (line 257)
C03-R2 attempt 3 (input 161900): FAILED - sed replaced 'local rc' with bare 'rc' (command not found)
C03-R2 attempt 4 (input 162331): FAILED - grep -c || echo 0 produces "0\n0" breaking TSV (3 NO gates); protected paths includes .git (1 NO gate)
C03-R2 attempt 5 (input 170506, OUT 170507): 22/24 YES; repeat10 printf 6 %s vs 8 args (upstream_stock_oracle NO); .git not excluded (source_asset_guards NO)
C03-R2 attempt 6 (input 171500, OUT 174356): 22/24 YES; same 2 NO — fix 5 sed didn't match, fix 6 sed didn't match
C03-R2 attempt 7 (this input 182702): 
  All previous fixes applied via edit tool (not sed):
  Fix 1: find|head wrapped with set +o pipefail + -maxdepth 3
  Fix 2: deleted 'local rc'/'local vfs_rc' lines outside functions
  Fix 3: grep -c || echo 0 → grep -c || true
  Fix 5: repeat10 printf 6 %s → 8 %s (added \t%s\t%s for $bad and $local_log)
  Fix 7: gate check 'for id in U1 U3' → 'for tn in "$U1" "$U3"' (use full test names, not short IDs)
  Fix 8: find command add -not -path "*/.git/*" -not -name ".git" (both before and after snapshots)
