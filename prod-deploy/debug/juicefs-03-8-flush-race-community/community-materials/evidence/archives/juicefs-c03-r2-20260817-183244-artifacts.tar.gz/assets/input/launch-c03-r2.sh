#!/bin/bash
set -Eeuo pipefail
umask 077

# C03-R2 Launcher: validates RUN_ID, calls runner in foreground, captures rc, writes sidecars

RUN_ID="${1:-}"
if [ -z "$RUN_ID" ]; then
  echo "Usage: $0 RUN_ID" >&2
  exit 1
fi
if ! [[ "$RUN_ID" =~ ^[0-9]{8}-[0-9]{6}$ ]]; then
  echo "RUN_ID must be YYYYmmdd-HHMMSS" >&2
  exit 1
fi

LAUNCHER_REAL=$(readlink -f -- "${BASH_SOURCE[0]}")
INPUT_DIR=$(dirname -- "$LAUNCHER_REAL")
RUNNER="$INPUT_DIR/run-c03-r2.sh"
OUT="/home/lilingfeng/tmp/juicefs-c03-r2-$RUN_ID"
ARCHIVE="$OUT-artifacts.tar.gz"
LAUNCH_LOG="/home/lilingfeng/tmp/juicefs-c03-r2-$RUN_ID.launch.log"

# Verify paths don't pre-exist
if [ -e "$OUT" ] || [ -e "$ARCHIVE" ] || [ -e "$LAUNCH_LOG" ]; then
  echo "Path conflict: OUT/archive/launch-log already exists" >&2
  exit 1
fi

# Verify runner exists and is readable
if [ ! -f "$RUNNER" ]; then
  echo "Runner not found: $RUNNER" >&2
  exit 1
fi

# Launch runner in foreground
bash "$RUNNER" "$RUN_ID" > "$LAUNCH_LOG" 2>&1
RUNNER_RC=$?

# Write runner rc sidecar
printf '%s\n' "$RUNNER_RC" > "$OUT.runner.rc"

# Write launch log SHA
sha256sum "$LAUNCH_LOG" > "$OUT.launch-log.sha256"

# Write final status (only if runner rc=0 and integrity passes)
if [ -f "$OUT.meta/prearchive-status.txt" ] && [ -f "$ARCHIVE.integrity.tsv" ]; then
  PREARCHIVE=$(cat "$OUT/meta/prearchive-status.txt")
  INTEGRITY_ALL_YES=YES
  while IFS=$'\t' read -r key val; do
    [ "$val" = "YES" ] || INTEGRITY_ALL_YES=NO
  done < "$ARCHIVE.integrity.tsv"
  if [ "$RUNNER_RC" -eq 0 ] && [ "$PREARCHIVE" = "ALL-REQUIRED-GATES-YES" ] && [ "$INTEGRITY_ALL_YES" = YES ]; then
    printf '%s\n' "PASS-B-PR-READY-LOCAL" > "$ARCHIVE.final-status.txt"
  else
    printf '%s\n' "$PREARCHIVE" > "$ARCHIVE.final-status.txt"
  fi
else
  printf '%s\n' "RUNNER-FAILED-rc=$RUNNER_RC" > "$OUT.final-status-fallback.txt"
fi

echo "Launcher complete. Runner rc=$RUNNER_RC"
