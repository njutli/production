#!/bin/bash
set -Eeuo pipefail
umask 077

# ============================================================
# C03-R2 Runner — PR Readiness Audit Clean Rerun
# Key fixes from R1: dynamic self-localization, if/else rc,
# precise TSV counts, protected paths, input double-check,
# gate single-resolution, archive self-verification
# ============================================================

RUNNER_REAL=$(readlink -f -- "${BASH_SOURCE[0]}")
INPUT_DIR=$(dirname -- "$RUNNER_REAL")
RUN_ID="${1:-}"
test -n "$RUN_ID" || { echo "RUN_ID required" >&2; exit 1; }

SOURCE=/home/lilingfeng/project/juicefs
C02_BASE=edabf9c24601510476e7453abff177f4aaca07ac
C03_REF=a617e1b016967137de5bdf099cb8b8415cb1d06d
GOPROXY_VAL=https://goproxy.cn,direct
BASELINE_RE='^(TestSmode|TestEntryString|TestError|TestVFSIO)$'

U1=TestFullBlockDispatchedWhenSliceIDBecomesReady
U2=TestPartialBlockNotDispatchedWhenSliceIDBecomesReady
U3=TestFlushErrorRecordedWhenSliceIDBecomesReady
COMMUNITY_RE="^(${U1}|${U2}|${U3})$"
C02_ALL_RE='^TestC02(FullBlockDispatchAfterDelayedID|MultiBlockDispatchUsesLatestLength|FlushToFailureIsObservable|PartialThenFullAfterIDDispatchesOnce|DelayedNewSliceDoesNotBlockWriteAt|NonEIONewSliceDoesNotRetryBeforeFlush|TransientEIORecoversOnFreeze|PermanentENOSPCAbortsFrozenSlice|FrozenSliceSkipsCatchupFlush|ConcurrentIndependentFullBlocks)$'
C02_TESTS=(TestC02FullBlockDispatchAfterDelayedID TestC02MultiBlockDispatchUsesLatestLength TestC02FlushToFailureIsObservable TestC02PartialThenFullAfterIDDispatchesOnce TestC02DelayedNewSliceDoesNotBlockWriteAt TestC02NonEIONewSliceDoesNotRetryBeforeFlush TestC02TransientEIORecoversOnFreeze TestC02PermanentENOSPCAbortsFrozenSlice TestC02FrozenSliceSkipsCatchupFlush TestC02ConcurrentIndependentFullBlocks)

OUT="/home/lilingfeng/tmp/juicefs-c03-r2-$RUN_ID"
ARCHIVE="$OUT-artifacts.tar.gz"
VERIFY_DIR="/home/lilingfeng/tmp/juicefs-c03-r2-verify-$RUN_ID"

# Gate model: single resolution
declare -A GATE_STATUS GATE_EVIDENCE GATE_RESOLVED
GATE_NAMES=(input_integrity upstream_freeze upstream_policy_ci upstream_stock_oracle B_standard_apply B_community_single B_community_count100 B_community_race20 Q_semantic_single Q_semantic_count100 Q_semantic_race20 B_full_vfs redis_lifecycle B_gofmt_diff_license B_tidy B_vet B_lint B_linux_build B_lite_build patch_replay community_search community_drafts_secret_scan source_asset_guards execution_audit)
for g in "${GATE_NAMES[@]}"; do GATE_STATUS[$g]=NOT_RUN; GATE_RESOLVED[$g]=0; done

resolve_gate() {
  local name=$1 status=$2 evidence=$3
  if [ "${GATE_RESOLVED[$name]}" -ge 1 ]; then
    echo "FATAL: gate $name already resolved" >&2
    exit 99
  fi
  GATE_STATUS[$name]=$status
  GATE_EVIDENCE[$name]=$evidence
  GATE_RESOLVED[$name]=1
}

# rc capture helper
capture_rc() { if "$@"; then echo 0; else echo $?; fi; }

# Anchor recorder
record_anchor() { printf '%s\n' "$1" >> "$OUT/meta/anchors.actual"; echo "$1"; }

# Trap: only clean Redis
REDIS_CONTAINERS=""
trap 'for cid in $REDIS_CONTAINERS; do docker stop "$cid" 2>/dev/null || true; done' EXIT

# Create OUT
mkdir -p "$OUT"/{assets/input,artifacts,builds,cache/{go-build-125,go-build-126,go-mod,go-tmp,os-tmp},community-search,diffs,drafts,logs,meta,rc,services,src,tools}

# Write commands.sh
printf 'bash %s %s\n' "$RUNNER_REAL" "$RUN_ID" > "$OUT/commands.sh"
printf 'RUNNER_REAL=%s\nINPUT_DIR=%s\nOUT=%s\nRUN_ID=%s\n' "$RUNNER_REAL" "$INPUT_DIR" "$OUT" "$RUN_ID" >> "$OUT/commands.sh"

# Save executed chain
printf 'executed_runner_realpath\t%s\n' "$RUNNER_REAL" >> "$OUT/meta/executed-chain.tsv"
RUNNER_SHA=$(sha256sum "$RUNNER_REAL" | cut -d' ' -f1)
printf 'executed_runner_sha256\t%s\n' "$RUNNER_SHA" >> "$OUT/meta/executed-chain.tsv"
LAUNCHER_REAL=$(readlink -f -- "$INPUT_DIR/launch-c03-r2.sh")
LAUNCHER_SHA=$(sha256sum "$LAUNCHER_REAL" | cut -d' ' -f1)
printf 'executed_launcher_realpath\t%s\n' "$LAUNCHER_REAL" >> "$OUT/meta/executed-chain.tsv"
printf 'executed_launcher_sha256\t%s\n' "$LAUNCHER_SHA" >> "$OUT/meta/executed-chain.tsv"

# Copy input to assets/input
cp -a "$INPUT_DIR"/* "$OUT/assets/input/" 2>/dev/null || true
# Remove manifest files from copy (they'll be regenerated)
rm -f "$OUT/assets/input/input.sha256" "$OUT/assets/input/input.stat.tsv" "$OUT/assets/input/input.expected-files" 2>/dev/null || true

# Verify runner hash match
INPUT_RUNNER="$INPUT_DIR/run-c03-r2.sh"
ARCHIVED_RUNNER="$OUT/assets/input/run-c03-r2.sh"
if cmp -s "$RUNNER_REAL" "$INPUT_RUNNER"; then
  echo "runner matches input"
else
  echo "FATAL: runner mismatch" >&2
  resolve_gate input_integrity NO "runner_mismatch"
fi
if cmp -s "$RUNNER_REAL" "$ARCHIVED_RUNNER"; then
  echo "runner matches archived"
else
  echo "FATAL: archived runner mismatch" >&2
  resolve_gate input_integrity NO "archived_runner_mismatch"
fi

# Init gates TSV
printf 'gate\tstatus\tevidence\n' > "$OUT/meta/candidate-gates.initial.tsv"
for g in "${GATE_NAMES[@]}"; do printf '%s\tNOT_RUN\t\n' "$g" >> "$OUT/meta/candidate-gates.initial.tsv"; done

# Runtime adaptations TSV
printf 'timestamp\ttype\tdetail\tevidence\n' > "$OUT/meta/runtime-adaptations.tsv"
printf '%s\tNONE_AFTER_START\tno runtime adaptation yet\t-\n' "$(date -Iseconds)" >> "$OUT/meta/runtime-adaptations.tsv"

# Enable xtrace
exec 19>>"$OUT/logs/shell-xtrace.log"
export BASH_XTRACEFD=19
PS4='+C03R2 ${BASH_SOURCE##*/}:${LINENO}: '
set -x
record_anchor C03R2_ANCHOR:INIT

# === Input start check ===
( cd "$INPUT_DIR" && sha256sum -c input.sha256 ) > "$OUT/meta/input-check-start.log" 2>&1
START_INPUT_RC=$?
printf '%s\n' "$START_INPUT_RC" > "$OUT/rc/input-check-start.rc"
if [ "$START_INPUT_RC" -ne 0 ]; then
  echo "FATAL: input SHA mismatch at start" >&2
  resolve_gate input_integrity NO "input-check-start.log"
fi

# Save input stat snapshot
INPUT_SHA_START=$(sha256sum "$INPUT_DIR/input.sha256" "$INPUT_DIR/input.stat.tsv" 2>/dev/null | sha256sum | cut -d' ' -f1)
printf '%s\n' "$INPUT_SHA_START" > "$OUT/meta/input-manifest-start.sha256"

# === Step 2: PROTECT_SNAPSHOT ===
record_anchor C03R2_ANCHOR:PROTECT_SNAPSHOT

# SOURCE snapshot
git -C "$SOURCE" rev-parse HEAD > "$OUT/meta/source-head-before.txt" 2>&1 || true
git -C "$SOURCE" status --porcelain=v2 --untracked-files=all > "$OUT/meta/source-status-before.txt" 2>&1 || true
git -C "$SOURCE" remote -v > "$OUT/meta/source-remote-before.txt" 2>&1 || true

# Protected paths snapshot
printf 'path\ttype\tmode\tuid\tgid\tsize\tmtime_ns\tlink_target\n' > "$OUT/meta/protected-before.tsv"
while IFS= read -r p; do
  [ -e "$p" ] || { printf '%s\tMISSING_BEFORE\t-\t-\t-\t-\t-\t-\n' "$p" >> "$OUT/meta/protected-before.tsv"; continue; }
  if [ -d "$p" ]; then
    set +o pipefail; find "$p" -maxdepth 3 -not -path "*/juicefs-c03-r2-*" -not -path "*/juicefs-c03-r2-verify-*" -not -path "*/.git/*" -not -name ".git" -printf '%p\tdir\t%m\t%u\t%g\t%s\t%T@\t%l\n' 2>/dev/null | head -5000 >> "$OUT/meta/protected-before.tsv"; set -o pipefail
  elif [ -f "$p" ]; then
    stat --printf='%n\tfile\t%a\t%u\t%g\t%s\t%Y\t\n' "$p" 2>/dev/null >> "$OUT/meta/protected-before.tsv"
  fi
done < "$INPUT_DIR/protected-paths.txt"
sha256sum "$OUT/meta/protected-before.tsv" > "$OUT/meta/protected-before.sha256"

# === Step 3: Fetch upstream ===
record_anchor C03R2_ANCHOR:FETCH
git clone --no-hardlinks --no-checkout "$SOURCE" "$OUT/src/upstream-fetch" > "$OUT/logs/clone-upstream.log" 2>&1
git -C "$OUT/src/upstream-fetch" remote set-url origin https://github.com/juicedata/juicefs
git ls-remote https://github.com/juicedata/juicefs refs/heads/main > "$OUT/meta/ls-remote-before.txt" 2>&1
git -C "$OUT/src/upstream-fetch" fetch --no-tags origin main > "$OUT/logs/fetch.log" 2>&1
git ls-remote https://github.com/juicedata/juicefs refs/heads/main > "$OUT/meta/ls-remote-after.txt" 2>&1

UPSTREAM_COMMIT=$(git -C "$OUT/src/upstream-fetch" rev-parse FETCH_HEAD)
printf '%s\n' "$UPSTREAM_COMMIT" > "$OUT/meta/upstream-commit.txt"
git -C "$OUT/src/upstream-fetch" show -s --format='%H%n%aI%n%s%n%P' "$UPSTREAM_COMMIT" > "$OUT/meta/upstream-commit-show.txt"
git -C "$OUT/src/upstream-fetch" merge-base --is-ancestor "$C02_BASE" "$UPSTREAM_COMMIT" && ANCESTOR_C2=0 || ANCESTOR_C2=1
git -C "$OUT/src/upstream-fetch" merge-base --is-ancestor "$C03_REF" "$UPSTREAM_COMMIT" && ANCESTOR_C3=0 || ANCESTOR_C3=1
printf "c02_ancestor\t%s\nc03_ancestor\t%s\n" "$ANCESTOR_C2" "$ANCESTOR_C3" > "$OUT/meta/upstream-ancestry.tsv"
git -C "$OUT/src/upstream-fetch" rev-list --count "$C02_BASE..$UPSTREAM_COMMIT" > "$OUT/meta/upstream-distance.txt"

# Save policy files
cd "$OUT/src/upstream-fetch"
git checkout "$UPSTREAM_COMMIT" -- CONTRIBUTING.md .github/workflows/verify.yml .github/workflows/unittests.yml .github/actions/build/action.yml .golangci.yml go.mod go.sum Makefile 2>/dev/null || true
mkdir -p "$OUT/meta/upstream-policy"
cp CONTRIBUTING.md .github/workflows/verify.yml .golangci.yml go.mod Makefile "$OUT/meta/upstream-policy/" 2>/dev/null || true
sha256sum CONTRIBUTING.md .github/workflows/verify.yml .golangci.yml go.mod Makefile > "$OUT/meta/upstream-policy-hashes.txt" 2>/dev/null || true
grep '^go ' go.mod > "$OUT/meta/upstream-go-directive.txt" 2>/dev/null || true
printf 'go_directive\t%s\n' "$(awk '{print $2}' "$OUT/meta/upstream-go-directive.txt" 2>/dev/null)" > "$OUT/meta/upstream-ci-matrix.tsv"
grep -i 'golangci\|go-version' .github/workflows/verify.yml 2>/dev/null | head -5 >> "$OUT/meta/upstream-ci-matrix.tsv" || true
resolve_gate upstream_freeze YES "meta/upstream-commit.txt"
resolve_gate upstream_policy_ci YES "meta/upstream-ci-matrix.tsv"

# === Step 4: Four arms + toolchain + baseline ===
for ARM in S-oracle B-candidate Q-semantic R-replay; do
  git clone --no-hardlinks --no-checkout "$OUT/src/upstream-fetch" "$OUT/src/$ARM" > "$OUT/logs/clone-$ARM.log" 2>&1
  git -C "$OUT/src/$ARM" cat-file -e "$UPSTREAM_COMMIT^{commit}" >> "$OUT/logs/clone-$ARM.log" 2>&1
  git -C "$OUT/src/$ARM" checkout --detach "$UPSTREAM_COMMIT" >> "$OUT/logs/clone-$ARM.log" 2>&1
  HEAD_NOW=$(git -C "$OUT/src/$ARM" rev-parse HEAD)
  printf '%s\t%s\n' "$ARM" "$HEAD_NOW" >> "$OUT/meta/arm-heads-before.tsv"
  git -C "$OUT/src/$ARM" status --porcelain > "$OUT/meta/$ARM-status-before.txt"
done
# Static conflict check
git -C "$OUT/src/S-oracle" grep -n 'func TestMain' -- 'pkg/vfs/*_test.go' > "$OUT/logs/static-vfs-testmain.log" 2>&1 || true
git -C "$OUT/src/S-oracle" grep -n -E "$U1|$U2|$U3" -- 'pkg/vfs/*_test.go' > "$OUT/logs/static-test-name-conflict.log" 2>&1 || true
git -C "$OUT/src/S-oracle" rev-parse "$UPSTREAM_COMMIT:pkg/vfs/writer.go" > "$OUT/meta/upstream-writer-blob.txt" 2>/dev/null || true

export GOPROXY="$GOPROXY_VAL" GOMODCACHE="$OUT/cache/go-mod" GOTMPDIR="$OUT/cache/go-tmp" TMPDIR="$OUT/cache/os-tmp" GOFLAGS=-mod=readonly
env GOTOOLCHAIN=go1.25.7 GOCACHE="$OUT/cache/go-build-125" go version > "$OUT/meta/go125-version.txt" 2>&1
env GOTOOLCHAIN=local GOCACHE="$OUT/cache/go-build-126" go version > "$OUT/meta/go126-version.txt" 2>&1
grep -q '^go version go1\.25\.7 linux/amd64$' "$OUT/meta/go125-version.txt"
grep -q '^go version go1\.26\.0 linux/amd64$' "$OUT/meta/go126-version.txt"
env GOTOOLCHAIN=go1.25.7 GOCACHE="$OUT/cache/go-build-125" go env GOOS GOARCH GOVERSION GOTOOLCHAIN GOPROXY GOMODCACHE GOCACHE GOTMPDIR CGO_ENABLED CC > "$OUT/meta/go125-env.txt" 2>&1
env GOTOOLCHAIN=local GOCACHE="$OUT/cache/go-build-126" go env GOOS GOARCH GOVERSION GOTOOLCHAIN GOPROXY GOMODCACHE GOCACHE GOTMPDIR CGO_ENABLED CC > "$OUT/meta/go126-env.txt" 2>&1

cd "$OUT/src/S-oracle"
for attempt in 1 2 3; do
  if env GOTOOLCHAIN=go1.25.7 GOCACHE="$OUT/cache/go-build-125" go mod download > "$OUT/logs/go125-mod-download.log" 2>&1; then break; fi
  sed -i '/NONE_AFTER_START/d' "$OUT/meta/runtime-adaptations.tsv"
  printf '%s\tmod_download_retry\tattempt %s failed\tlogs/go125-mod-download.log\n' "$(date -Iseconds)" "$attempt" >> "$OUT/meta/runtime-adaptations.tsv"
  sleep 5
done
printf '%s\n' "$?" > "$OUT/rc/go125-mod-download.rc"
env GOTOOLCHAIN=local GOCACHE="$OUT/cache/go-build-126" go mod download > "$OUT/logs/go126-mod-download.log" 2>&1
printf '%s\n' "$?" > "$OUT/rc/go126-mod-download.rc"
for TOOL in go125 go126; do
  if [ "$TOOL" = go125 ]; then TC=go1.25.7; BC=$OUT/cache/go-build-125; else TC=local; BC=$OUT/cache/go-build-126; fi
  ( cd "$OUT/src/S-oracle" && env GOTOOLCHAIN="$TC" GOCACHE="$BC" go test ./pkg/vfs -run '^$' -count=1 -timeout=5m ) > "$OUT/logs/$TOOL-baseline-compile.log" 2>&1
  printf '%s\n' "$?" > "$OUT/rc/$TOOL-baseline-compile.rc"
  ( cd "$OUT/src/S-oracle" && env GOTOOLCHAIN="$TC" GOCACHE="$BC" go test ./pkg/vfs -run "$BASELINE_RE" -count=1 -v -timeout=10m ) > "$OUT/logs/$TOOL-baseline-memory.log" 2>&1
  printf '%s\n' "$?" > "$OUT/rc/$TOOL-baseline-memory.rc"
done

# Helper: run go test and record results
run_and_record() {
  local tool=$1 tc=$2 bc=$3 arm=$4 mode=$5 test_name=$6
  local id="${7:-$test_name}"
  local log_rel="logs/${tool}-${arm}-${id}-${mode}.log"
  local rc
  if ( cd "$OUT/src/$arm" && env GOTOOLCHAIN="$tc" GOCACHE="$bc" GOFLAGS=-mod=readonly GOPROXY="$GOPROXY_VAL" GOMODCACHE="$OUT/cache/go-mod" GOTMPDIR="$OUT/cache/go-tmp" TMPDIR="$OUT/cache/os-tmp" go test ./pkg/vfs -run "^${test_name}$" -count=1 -v -timeout=2m ) > "$OUT/$log_rel" 2>&1; then rc=0; else rc=$?; fi
  printf '%s\n' "$rc" > "$OUT/rc/${tool}-${arm}-${id}-${mode}.rc"
  local pass=$(grep -c -- "--- PASS: $test_name" "$OUT/$log_rel" 2>/dev/null || true)
  local fail=$(grep -c -- "--- FAIL: $test_name" "$OUT/$log_rel" 2>/dev/null || true)
  local bad=0; grep -Eq '\[build failed\]|panic:|fatal error:|test timed out|DATA RACE|no tests to run' "$OUT/$log_rel" && bad=1
  printf '%s\t%s\tsingle\t%s\t%s\t1\t1\t%s\t%s\t0\t%s\t%s\n' "$arm" "$tool" "$test_name" "$rc" "$pass" "$fail" "$bad" "$log_rel"
}

run_count_and_record() {
  local tool=$1 tc=$2 bc=$3 arm=$4 mode=$5 re=$6 count=$7 test_names=$8
  local log_rel="logs/${tool}-${arm}-${mode}.log"
  local extra=""; [ "$mode" = "race20" ] && extra="-race"
  local rc
  if ( cd "$OUT/src/$arm" && env GOTOOLCHAIN="$tc" GOCACHE="$bc" GOFLAGS=-mod=readonly GOPROXY="$GOPROXY_VAL" GOMODCACHE="$OUT/cache/go-mod" GOTMPDIR="$OUT/cache/go-tmp" TMPDIR="$OUT/cache/os-tmp" go test $extra ./pkg/vfs -run "$re" -count=$count -v -timeout=20m ) > "$OUT/$log_rel" 2>&1; then rc=0; else rc=$?; fi
  printf '%s\n' "$rc" > "$OUT/rc/${tool}-${arm}-${mode}.rc"
  local bad=0; grep -Eq '\[build failed\]|panic:|fatal error:|test timed out|DATA RACE|no tests to run' "$OUT/$log_rel" && bad=1
  while IFS= read -r tn; do
    local pass=$(grep -c -- "--- PASS: $tn" "$OUT/$log_rel" 2>/dev/null || true)
    local fail=$(grep -c -- "--- FAIL: $tn" "$OUT/$log_rel" 2>/dev/null || true)
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$arm" "$tool" "$mode" "$tn" "$rc" "$count" "$count" "$pass" "$fail" "$bad" "$log_rel"
  done <<< "$test_names"
}

# === Step 5: S-oracle ===
record_anchor C03R2_ANCHOR:STOCK_ORACLE
cp "$INPUT_DIR/writer_flush_test.go" "$OUT/src/S-oracle/pkg/vfs/writer_flush_test.go"
git -C "$OUT/src/S-oracle" add -N pkg/vfs/writer_flush_test.go

printf 'arm\ttool\tmode\ttest\tactual_rc\texpected_run\texpected_pass\tactual_pass\tactual_fail\tbad\tlog\n' > "$OUT/meta/stock-results.tsv"
for TOOL in go125 go126; do
  if [ "$TOOL" = go125 ]; then TC=go1.25.7; BC=$OUT/cache/go-build-125; else TC=local; BC=$OUT/cache/go-build-126; fi
  run_and_record "$TOOL" "$TC" "$BC" S-oracle single "$U2" "U2" >> "$OUT/meta/stock-results.tsv"
  run_and_record "$TOOL" "$TC" "$BC" S-oracle single "$U1" "U1" >> "$OUT/meta/stock-results.tsv"
  run_and_record "$TOOL" "$TC" "$BC" S-oracle single "$U3" "U3" >> "$OUT/meta/stock-results.tsv"
  for id_tn in "U1:$U1" "U3:$U3"; do
    id="${id_tn%%:*}"; tn="${id_tn##*:}"
    for iter in 01 02 03 04 05 06 07 08 09 10; do
      local_log="logs/${TOOL}-S-oracle-${id}-repeat-${iter}.log"
      if ( cd "$OUT/src/S-oracle" && env GOTOOLCHAIN="$TC" GOCACHE="$BC" GOFLAGS=-mod=readonly GOPROXY="$GOPROXY_VAL" GOMODCACHE="$OUT/cache/go-mod" GOTMPDIR="$OUT/cache/go-tmp" TMPDIR="$OUT/cache/os-tmp" go test ./pkg/vfs -run "^${tn}$" -count=1 -v -timeout=2m ) > "$OUT/$local_log" 2>&1; then rc=0; else rc=$?; fi
      printf '%s\n' "$rc" > "$OUT/rc/${TOOL}-S-oracle-${id}-repeat-${iter}.rc"
      mc=$(grep -c 'not.*dispatched' "$OUT/$local_log" 2>/dev/null || true)
      fc=$(grep -c -- "--- FAIL: $tn" "$OUT/$local_log" 2>/dev/null || true)
      bad=0; grep -Eq '\[build failed\]|panic:|fatal error:|test timed out|DATA RACE' "$OUT/$local_log" && bad=1
      printf '%s\t%s\trepeat10\t%s\t%s\t1\t0\t0\t%s\t%s\t%s\t%s\n' "S-oracle" "$TOOL" "$tn" "$rc" "$mc" "$fc" "$bad" "$local_log" >> "$OUT/meta/stock-results.tsv"
    done
  done
done

# Stock oracle gate
STOCK_OK=YES
for TOOL in go125 go126; do
  grep -q "${TOOL}.*single.*$U2.*0.*1.*1.*0.*0" "$OUT/meta/stock-results.tsv" || STOCK_OK=NO
  for tn in "$U1" "$U3"; do
    grep -q "${TOOL}.*single.*${tn}.*1.*1.*0" "$OUT/meta/stock-results.tsv" || STOCK_OK=NO
  done
done
resolve_gate upstream_stock_oracle "$STOCK_OK" "meta/stock-results.tsv"

# === Step 6: B apply + community ===
record_anchor C03R2_ANCHOR:APPLY_B
if git -C "$OUT/src/B-candidate" apply --check "$INPUT_DIR/async-catchup-main.patch" > "$OUT/logs/B-apply-check.log" 2>&1 && \
   git -C "$OUT/src/B-candidate" apply "$INPUT_DIR/async-catchup-main.patch" > "$OUT/logs/B-apply.log" 2>&1; then
  resolve_gate B_standard_apply YES "rc/B-apply-check.rc,rc/B-apply.rc"
else
  resolve_gate B_standard_apply NO "B apply failed"
fi
env GOTOOLCHAIN=local GOCACHE="$OUT/cache/go-build-126" gofmt -w "$OUT/src/B-candidate/pkg/vfs/writer.go"
cp "$INPUT_DIR/writer_flush_test.go" "$OUT/src/B-candidate/pkg/vfs/writer_flush_test.go"
git -C "$OUT/src/B-candidate" add -N pkg/vfs/writer_flush_test.go

printf 'arm\ttool\tmode\ttest\tactual_rc\texpected_run\texpected_pass\tactual_pass\tactual_fail\tbad\tlog\n' > "$OUT/meta/community-results.tsv"
B_SINGLE=YES; B_COUNT=YES; B_RACE=YES
for TOOL in go125 go126; do
  if [ "$TOOL" = go125 ]; then TC=go1.25.7; BC=$OUT/cache/go-build-125; else TC=local; BC=$OUT/cache/go-build-126; fi
  for id_tn in "U1:$U1" "U2:$U2" "U3:$U3"; do
    id="${id_tn%%:*}"; tn="${id_tn##*:}"
    run_and_record "$TOOL" "$TC" "$BC" B-candidate single "$tn" "$id" >> "$OUT/meta/community-results.tsv"
    [ "$(tail -1 "$OUT/meta/community-results.tsv" | awk -F'\t' '{print $5}')" = "0" ] || B_SINGLE=NO
  done
  run_count_and_record "$TOOL" "$TC" "$BC" B-candidate count100 "$COMMUNITY_RE" 100 "$U1\n$U2\n$U3" >> "$OUT/meta/community-results.tsv"
  [ "$(cat "$OUT/rc/${TOOL}-B-candidate-count100.rc")" = "0" ] || B_COUNT=NO
  run_count_and_record "$TOOL" "$TC" "$BC" B-candidate race20 "$COMMUNITY_RE" 20 "$U1\n$U2\n$U3" >> "$OUT/meta/community-results.tsv"
  [ "$(cat "$OUT/rc/${TOOL}-B-candidate-race20.rc")" = "0" ] || B_RACE=NO
  grep -q 'DATA RACE' "$OUT/logs/${TOOL}-B-candidate-race20.log" 2>/dev/null && B_RACE=NO
done
resolve_gate B_community_single "$B_SINGLE" "meta/community-results.tsv"
resolve_gate B_community_count100 "$B_COUNT" "meta/community-results.tsv"
resolve_gate B_community_race20 "$B_RACE" "meta/community-results.tsv"

# === Step 7: Q semantic ===
record_anchor C03R2_ANCHOR:SEMANTIC
git -C "$OUT/src/Q-semantic" apply --check "$INPUT_DIR/async-catchup-main.patch" > "$OUT/logs/Q-apply-check.log" 2>&1
git -C "$OUT/src/Q-semantic" apply "$INPUT_DIR/async-catchup-main.patch" > "$OUT/logs/Q-apply.log" 2>&1
env GOTOOLCHAIN=local GOCACHE="$OUT/cache/go-build-126" gofmt -w "$OUT/src/Q-semantic/pkg/vfs/writer.go"
cp "$INPUT_DIR/writer_flush_c02_test.go" "$OUT/src/Q-semantic/pkg/vfs/writer_flush_c02_test.go"
git -C "$OUT/src/Q-semantic" add -N pkg/vfs/writer_flush_c02_test.go

printf 'arm\ttool\tmode\ttest\tactual_rc\texpected_run\texpected_pass\tactual_pass\tactual_fail\tbad\tlog\n' > "$OUT/meta/semantic-results.tsv"
Q_SINGLE=YES; Q_COUNT=YES; Q_RACE=YES
C02_TESTS_STR=$(printf '%s\n' "${C02_TESTS[@]}")
for TOOL in go125 go126; do
  if [ "$TOOL" = go125 ]; then TC=go1.25.7; BC=$OUT/cache/go-build-125; else TC=local; BC=$OUT/cache/go-build-126; fi
  for tn in "${C02_TESTS[@]}"; do
    short="${tn#TestC02}"
    run_and_record "$TOOL" "$TC" "$BC" Q-semantic single "$tn" "$short" >> "$OUT/meta/semantic-results.tsv"
    [ "$(tail -1 "$OUT/meta/semantic-results.tsv" | awk -F'\t' '{print $5}')" = "0" ] || Q_SINGLE=NO
  done
  run_count_and_record "$TOOL" "$TC" "$BC" Q-semantic count100 "$C02_ALL_RE" 100 "$C02_TESTS_STR" >> "$OUT/meta/semantic-results.tsv"
  [ "$(cat "$OUT/rc/${TOOL}-Q-semantic-count100.rc")" = "0" ] || Q_COUNT=NO
  run_count_and_record "$TOOL" "$TC" "$BC" Q-semantic race20 "$C02_ALL_RE" 20 "$C02_TESTS_STR" >> "$OUT/meta/semantic-results.tsv"
  [ "$(cat "$OUT/rc/${TOOL}-Q-semantic-race20.rc")" = "0" ] || Q_RACE=NO
  grep -q 'DATA RACE' "$OUT/logs/${TOOL}-Q-semantic-race20.log" 2>/dev/null && Q_RACE=NO
done
resolve_gate Q_semantic_single "$Q_SINGLE" "meta/semantic-results.tsv"
resolve_gate Q_semantic_count100 "$Q_COUNT" "meta/semantic-results.tsv"
resolve_gate Q_semantic_race20 "$Q_RACE" "meta/semantic-results.tsv"

# === Step 8: Full pkg/vfs + Redis ===
record_anchor C03R2_ANCHOR:FULL_VFS
docker version --format '{{.Server.Version}}' > "$OUT/meta/docker-version.txt" 2>&1
if ss -tlnp 2>/dev/null | grep -q ':6379 '; then
  resolve_gate B_full_vfs NO "REDIS-PORT-BLOCKED"
  resolve_gate redis_lifecycle NO "REDIS-PORT-BLOCKED"
else
  docker pull redis:7.2-alpine > "$OUT/logs/redis-pull.log" 2>&1 || true
  docker image inspect redis:7.2-alpine --format '{{.ID}} {{.RepoDigests}}' > "$OUT/meta/redis-image.txt" 2>&1 || true
  printf 'tool\tstep\texpected_rc\tactual_rc\tcontent_check\tstatus\tevidence\n' > "$OUT/meta/redis-lifecycle.tsv"
  B_VFS=YES; REDIS_LIFE=YES
  for TOOL in go125 go126; do
    if [ "$TOOL" = go125 ]; then TC=go1.25.7; BC=$OUT/cache/go-build-125; else TC=local; BC=$OUT/cache/go-build-126; fi
    CID=$(docker run -d --rm --name "juicefs-c03r2-redis-${RUN_ID}-${TOOL}" --label "juicefs.c03r2.run=${RUN_ID}" -p 127.0.0.1:6379:6379 --tmpfs /data redis:7.2-alpine redis-server --save '' --appendonly no 2>&1)
    REDIS_CONTAINERS="$REDIS_CONTAINERS $CID"
    sleep 2
    PONG_RC=0; docker exec "$CID" redis-cli ping > "$OUT/logs/redis-ping-${TOOL}.log" 2>&1 || PONG_RC=$?
    [ "$PONG_RC" -eq 0 ] || REDIS_LIFE=NO
    docker inspect "$CID" > "$OUT/logs/redis-inspect-${TOOL}.json" 2>&1 || true
    docker logs "$CID" > "$OUT/logs/redis-logs-${TOOL}.log" 2>&1 || true
    if ( cd "$OUT/src/B-candidate" && env GOTOOLCHAIN="$TC" GOCACHE="$BC" GOFLAGS=-mod=readonly GOPROXY="$GOPROXY_VAL" GOMODCACHE="$OUT/cache/go-mod" GOTMPDIR="$OUT/cache/go-tmp" TMPDIR="$OUT/cache/os-tmp" go test ./pkg/vfs -count=1 -v -timeout=15m ) > "$OUT/logs/${TOOL}-B-candidate-full-vfs.log" 2>&1; then vfs_rc=0; else vfs_rc=$?; fi
    printf '%s\n' "$vfs_rc" > "$OUT/rc/${TOOL}-B-candidate-full-vfs.rc"
    [ "$vfs_rc" -eq 0 ] || B_VFS=NO
    STOP_RC=0; docker stop "$CID" > "$OUT/logs/redis-stop-${TOOL}.log" 2>&1 || STOP_RC=$?
    [ "$STOP_RC" -eq 0 ] || REDIS_LIFE=NO
    docker ps -a --filter "id=$CID" --format '{{.ID}}' > "$OUT/logs/redis-gone-${TOOL}.log" 2>&1 || true
    [ ! -s "$OUT/logs/redis-gone-${TOOL}.log" ] || REDIS_LIFE=NO
    REDIS_CONTAINERS="${REDIS_CONTAINERS// $CID/}"
    # Record lifecycle row
    for step in "pull:0:0:log:logs/redis-pull.log" "run:0:0:cid:$CID" "pong:0:$PONG_RC:PONG:logs/redis-ping-${TOOL}.log" "inspect:0:0:json:logs/redis-inspect-${TOOL}.json" "vfs:0:$vfs_rc:pkg:logs/${TOOL}-B-candidate-full-vfs.log" "stop:0:$STOP_RC:rc:logs/redis-stop-${TOOL}.log" "gone:1:0:none:logs/redis-gone-${TOOL}.log"; do
      printf '%s\t%s\t%s\n' "$TOOL" "$step" >> "$OUT/meta/redis-lifecycle.tsv"
    done
  done
  resolve_gate B_full_vfs "$B_VFS" "rc/*-B-candidate-full-vfs.rc"
  resolve_gate redis_lifecycle "$REDIS_LIFE" "meta/redis-lifecycle.tsv"
fi

# === Step 9: gofmt/tidy/vet ===
cd "$OUT/src/B-candidate"
GOFMT_RC=0; env GOTOOLCHAIN=local GOCACHE="$OUT/cache/go-build-126" gofmt -d pkg/vfs/writer.go pkg/vfs/writer_flush_test.go > "$OUT/logs/gofmt-check.log" 2>&1 || GOFMT_RC=$?
printf '%s\n' "$GOFMT_RC" > "$OUT/rc/gofmt-check.rc"
DIFF_RC=0; git diff --check > "$OUT/logs/git-diff-check.log" 2>&1 || DIFF_RC=$?
printf '%s\n' "$DIFF_RC" > "$OUT/rc/git-diff-check.rc"
LICENSE=YES; head -2 pkg/vfs/writer_flush_test.go | grep -q 'JuiceFS' || LICENSE=NO

B_TIDY=YES; B_VET=YES
for TOOL in go125 go126; do
  if [ "$TOOL" = go125 ]; then TC=go1.25.7; BC=$OUT/cache/go-build-125; else TC=local; BC=$OUT/cache/go-build-126; fi
  sha256sum go.mod go.sum > "$OUT/meta/gomod-hash-before-${TOOL}.txt"
  TIDY_RC=0; env GOTOOLCHAIN="$TC" GOCACHE="$BC" GOPROXY="$GOPROXY_VAL" GOMODCACHE="$OUT/cache/go-mod" GOTMPDIR="$OUT/cache/go-tmp" TMPDIR="$OUT/cache/os-tmp" go mod tidy > "$OUT/logs/${TOOL}-mod-tidy.log" 2>&1 || TIDY_RC=$?
  printf '%s\n' "$TIDY_RC" > "$OUT/rc/${TOOL}-mod-tidy.rc"
  sha256sum go.mod go.sum > "$OUT/meta/gomod-hash-after-${TOOL}.txt"
  diff "$OUT/meta/gomod-hash-before-${TOOL}.txt" "$OUT/meta/gomod-hash-after-${TOOL}.txt" > /dev/null 2>&1 || B_TIDY=NO
  [ "$TIDY_RC" -eq 0 ] || B_TIDY=NO
  VET_RC=0; env GOTOOLCHAIN="$TC" GOCACHE="$BC" GOFLAGS=-mod=readonly GOPROXY="$GOPROXY_VAL" GOMODCACHE="$OUT/cache/go-mod" GOTMPDIR="$OUT/cache/go-tmp" TMPDIR="$OUT/cache/os-tmp" go vet ./pkg/vfs > "$OUT/logs/${TOOL}-vet.log" 2>&1 || VET_RC=$?
  printf '%s\n' "$VET_RC" > "$OUT/rc/${TOOL}-vet.rc"
  [ "$VET_RC" -eq 0 ] || B_VET=NO
done
[ "$GOFMT_RC" -eq 0 ] && [ "$LICENSE" = YES ] && resolve_gate B_gofmt_diff_license YES "rc/gofmt-check.rc" || resolve_gate B_gofmt_diff_license NO "rc/gofmt-check.rc"
resolve_gate B_tidy "$B_TIDY" "rc/*-mod-tidy.rc"
resolve_gate B_vet "$B_VET" "rc/*-vet.rc"

# === Step 10: golangci-lint ===
record_anchor C03R2_ANCHOR:LINT_BUILD
LINT_QUERY_RC=0; env GOTOOLCHAIN=go1.25.7 GOCACHE="$OUT/cache/go-build-125" GOPROXY="$GOPROXY_VAL" GOMODCACHE="$OUT/cache/go-mod" GOTMPDIR="$OUT/cache/go-tmp" TMPDIR="$OUT/cache/os-tmp" go list -m -versions github.com/golangci/golangci-lint/v2 > "$OUT/logs/lint-version-query.log" 2>&1 || LINT_QUERY_RC=$?
printf '%s\n' "$LINT_QUERY_RC" > "$OUT/rc/lint-version-query.rc"
LINT_VERSION=$(grep -oP 'v2\.6\.[0-9]+' "$OUT/logs/lint-version-query.log" 2>/dev/null | sort -V | tail -1)
echo "Selected: $LINT_VERSION" > "$OUT/meta/lint-version-selection.txt"
if [ -z "$LINT_VERSION" ]; then
  resolve_gate B_lint NO "LINT-INFRA-BLOCKED: no v2.6.x"
else
  LINT_INSTALL_RC=0; GOBIN="$OUT/tools/bin" env GOTOOLCHAIN=go1.25.7 GOCACHE="$OUT/cache/go-build-125" GOPROXY="$GOPROXY_VAL" GOMODCACHE="$OUT/cache/go-mod" GOTMPDIR="$OUT/cache/go-tmp" TMPDIR="$OUT/cache/os-tmp" go install "github.com/golangci/golangci-lint/v2/cmd/golangci-lint@$LINT_VERSION" > "$OUT/logs/lint-install.log" 2>&1 || LINT_INSTALL_RC=$?
  printf '%s\n' "$LINT_INSTALL_RC" > "$OUT/rc/lint-install.rc"
  if [ "$LINT_INSTALL_RC" -ne 0 ]; then resolve_gate B_lint NO "LINT-INFRA-BLOCKED: install"; else
    LINT_VER_RC=0; "$OUT/tools/bin/golangci-lint" version > "$OUT/logs/lint-version.log" 2>&1 || LINT_VER_RC=$?
    printf '%s\n' "$LINT_VER_RC" > "$OUT/rc/lint-version.rc"
    sha256sum "$OUT/tools/bin/golangci-lint" > "$OUT/meta/lint-binary.sha256"
    sha256sum "$OUT/src/B-candidate/.golangci.yml" > "$OUT/meta/golangci-yml.sha256"
    git -C "$OUT/src/B-candidate" status --porcelain > "$OUT/meta/lint-before-status.txt"
    LINT_RUN_RC=0; ( cd "$OUT/src/B-candidate" && env GOTOOLCHAIN=go1.25.7 GOCACHE="$OUT/cache/go-build-125" GOPROXY="$GOPROXY_VAL" GOMODCACHE="$OUT/cache/go-mod" GOTMPDIR="$OUT/cache/go-tmp" TMPDIR="$OUT/cache/os-tmp" "$OUT/tools/bin/golangci-lint" run ) > "$OUT/logs/lint-run.log" 2>&1 || LINT_RUN_RC=$?
    printf '%s\n' "$LINT_RUN_RC" > "$OUT/rc/lint-run.rc"
    git -C "$OUT/src/B-candidate" status --porcelain > "$OUT/meta/lint-after-status.txt"
    diff "$OUT/meta/lint-before-status.txt" "$OUT/meta/lint-after-status.txt" > "$OUT/logs/lint-status-diff.log" 2>&1 || true
    if [ "$LINT_RUN_RC" -eq 0 ] && [ "$LINT_VER_RC" -eq 0 ]; then resolve_gate B_lint YES "rc/lint-run.rc,meta/lint-binary.sha256"; else resolve_gate B_lint NO "LINT-FAIL rc=$LINT_RUN_RC"; fi
  fi
fi

# === Step 11: Build ===
B_LINUX=YES; B_LITE=YES
for TOOL in go125 go126; do
  if [ "$TOOL" = go125 ]; then TC=go1.25.7; BC=$OUT/cache/go-build-125; else TC=local; BC=$OUT/cache/go-build-126; fi
  mkdir -p "$OUT/builds/$TOOL"
  MK_RC=0; env GOTOOLCHAIN="$TC" GOCACHE="$BC" GOPROXY="$GOPROXY_VAL" GOMODCACHE="$OUT/cache/go-mod" GOTMPDIR="$OUT/cache/go-tmp" TMPDIR="$OUT/cache/os-tmp" make -B juicefs > "$OUT/logs/${TOOL}-make-juicefs.log" 2>&1 || MK_RC=$?
  printf '%s\n' "$MK_RC" > "$OUT/rc/${TOOL}-make-juicefs.rc"
  [ "$MK_RC" -eq 0 ] || B_LINUX=NO
  VER_RC=0; ./juicefs version > "$OUT/logs/${TOOL}-juicefs-version.log" 2>&1 || VER_RC=$?
  sha256sum ./juicefs > "$OUT/meta/${TOOL}-juicefs.sha256"
  cp ./juicefs "$OUT/builds/$TOOL/juicefs" 2>/dev/null || true
  MKL_RC=0; env GOTOOLCHAIN="$TC" GOCACHE="$BC" GOPROXY="$GOPROXY_VAL" GOMODCACHE="$OUT/cache/go-mod" GOTMPDIR="$OUT/cache/go-tmp" TMPDIR="$OUT/cache/os-tmp" make -B juicefs.lite > "$OUT/logs/${TOOL}-make-juicefs-lite.log" 2>&1 || MKL_RC=$?
  printf '%s\n' "$MKL_RC" > "$OUT/rc/${TOOL}-make-juicefs-lite.rc"
  [ "$MKL_RC" -eq 0 ] || B_LITE=NO
  ./juicefs.lite version > "$OUT/logs/${TOOL}-juicefs-lite-version.log" 2>&1 || true
  sha256sum ./juicefs.lite > "$OUT/meta/${TOOL}-juicefs-lite.sha256"
  cp ./juicefs.lite "$OUT/builds/$TOOL/juicefs.lite" 2>/dev/null || true
done
resolve_gate B_linux_build "$B_LINUX" "rc/*-make-juicefs.rc"
resolve_gate B_lite_build "$B_LITE" "rc/*-make-juicefs-lite.rc"

# Retained large files
printf 'path\tsize\tsha256\n' > "$OUT/meta/retained-large-files.tsv"
find "$OUT/builds" -type f -exec sha256sum {} \; >> "$OUT/meta/retained-large-files.tsv" 2>/dev/null || true

# === Step 12: Patch + replay ===
record_anchor C03R2_ANCHOR:REPLAY
git -C "$OUT/src/B-candidate" diff --binary --full-index -- pkg/vfs/writer.go pkg/vfs/writer_flush_test.go > "$OUT/artifacts/community-candidate.patch"
sha256sum "$OUT/artifacts/community-candidate.patch" > "$OUT/meta/community-patch.sha256"
cd "$OUT/src/R-replay"
R_CHECK_RC=0; git apply --check "$OUT/artifacts/community-candidate.patch" > "$OUT/logs/R-replay-apply-check.log" 2>&1 || R_CHECK_RC=$?
R_APPLY_RC=0; git apply "$OUT/artifacts/community-candidate.patch" > "$OUT/logs/R-replay-apply.log" 2>&1 || R_APPLY_RC=$?
printf '%s\n' "$R_CHECK_RC" > "$OUT/rc/R-replay-apply-check.rc"
printf '%s\n' "$R_APPLY_RC" > "$OUT/rc/R-replay-apply.rc"
git add -N pkg/vfs/writer_flush_test.go
git diff --binary --full-index -- pkg/vfs/writer.go pkg/vfs/writer_flush_test.go > "$OUT/diffs/R-replay-full.diff"
CMP_RC=0; cmp "$OUT/artifacts/community-candidate.patch" "$OUT/diffs/R-replay-full.diff" > "$OUT/logs/R-replay-diff-cmp.log" 2>&1 || CMP_RC=$?
printf '%s\n' "$CMP_RC" > "$OUT/rc/R-replay-diff-cmp.rc"
printf 'arm\ttool\tmode\ttest\tactual_rc\texpected_run\texpected_pass\tactual_pass\tactual_fail\tbad\tlog\n' > "$OUT/meta/replay-results.tsv"
for TOOL in go125 go126; do
  if [ "$TOOL" = go125 ]; then TC=go1.25.7; BC=$OUT/cache/go-build-125; else TC=local; BC=$OUT/cache/go-build-126; fi
  for id_tn in "U1:$U1" "U2:$U2" "U3:$U3"; do
    id="${id_tn%%:*}"; tn="${id_tn##*:}"
    run_and_record "$TOOL" "$TC" "$BC" R-replay single "$tn" "$id" >> "$OUT/meta/replay-results.tsv"
  done
  run_count_and_record "$TOOL" "$TC" "$BC" R-replay count20 "$COMMUNITY_RE" 20 "$U1\n$U2\n$U3" >> "$OUT/meta/replay-results.tsv"
done
[ "$CMP_RC" -eq 0 ] && resolve_gate patch_replay YES "rc/R-replay-diff-cmp.rc" || resolve_gate patch_replay NO "rc/R-replay-diff-cmp.rc"

# === Step 13: GitHub search ===
record_anchor C03R2_ANCHOR:COMMUNITY_SEARCH
QUERIES=("repo:juicedata/juicefs is:issue prepareID FlushTo" "repo:juicedata/juicefs is:pr prepareID FlushTo" 'repo:juicedata/juicefs is:issue "slice ID" writer flush' 'repo:juicedata/juicefs is:pr "full block" FlushTo' "repo:juicedata/juicefs is:issue random write flush block" "repo:juicedata/juicefs is:pr random write flush block")
SEARCH_OK=YES
for i in "${!QUERIES[@]}"; do
  q="${QUERIES[$i]}"
  printf '%s\n' "$q" > "$OUT/community-search/query-${i}.request.txt"
  date -Iseconds > "$OUT/community-search/query-${i}.started-at.txt"
  ENCODED=$(python3 -c "import urllib.parse,sys; print(urllib.parse.quote(sys.argv[1]))" "$q" 2>/dev/null || echo "$q")
  CURL_RC=0; curl -s -D "$OUT/community-search/query-${i}.headers.txt" -o "$OUT/community-search/query-${i}.body.json" -w '%{http_code}' "https://api.github.com/search/issues?q=$ENCODED" > "$OUT/community-search/query-${i}.http-status.txt" 2>&1 || CURL_RC=$?
  printf '%s\n' "$CURL_RC" > "$OUT/community-search/query-${i}.curl.rc"
  HTTP_STATUS=$(cat "$OUT/community-search/query-${i}.http-status.txt")
  [ "$CURL_RC" -eq 0 ] && [ "$HTTP_STATUS" = "200" ] || SEARCH_OK=NO
  python3 -c "import json; d=json.load(open('$OUT/community-search/query-${i}.body.json')); assert 'total_count' in d and 'items' in d" > "$OUT/community-search/query-${i}.validation.txt" 2>&1 || SEARCH_OK=NO
  sleep 3
done
git -C "$OUT/src/S-oracle" log --all --oneline --grep='prepareID\|FlushTo\|slice ID' > "$OUT/community-search/local-history-grep.txt" 2>&1 || true
git -C "$OUT/src/S-oracle" log --all --oneline -S 's.writer.SetID(s.id)' > "$OUT/community-search/local-history-S.txt" 2>&1 || true
printf 'url\tnumber\ttype\tstate\ttitle\tupdated_at\tquery\n' > "$OUT/community-search/candidates.tsv"
for i in "${!QUERIES[@]}"; do
  python3 -c "
import json
with open('$OUT/community-search/query-${i}.body.json') as f: d=json.load(f)
for item in d.get('items',[]):
  print(f\"{item.get('html_url','')}\t{item.get('number','')}\t{'pr' if 'pull' in item.get('html_url','') else 'issue'}\t{item.get('state','')}\t{item.get('title','')}\t{item.get('updated_at','')}\t${i}\")
" >> "$OUT/community-search/candidates.tsv" 2>/dev/null || true
done
printf 'duplicate_review_status\tDEFERRED_TO_CODEX\n' > "$OUT/community-search/duplicate-review-status.txt"
resolve_gate community_search "$SEARCH_OK" "community-search/"

# === Step 14: Drafts + secret scan ===
cat > "$OUT/drafts/issue.md" << 'DRAFT'
# Issue Title
VFS may miss dispatching a full block when the slice ID is prepared asynchronously

# Issue Body
**What happened**
When a write creates a new slice, `prepareID` runs asynchronously. If the first write fills at least one block before the slice ID is ready, `sliceWriter.write` skips `FlushTo` because `s.id == 0`. When the ID later becomes ready, the current code assigns it to the chunk writer but does not revisit the missed dispatch.

**What was expected**
After the slice ID becomes available, a non-frozen slice that already contains at least one complete block should dispatch those complete blocks exactly once. A partial or frozen slice should retain its existing behavior.

**Minimal reproduction**
The attached in-memory unit test delays `NewSlice`, writes one complete block, then releases the ID allocation. It fails on stock and passes with the proposed catch-up logic.

**Environment**
- JuiceFS commit: (to be filled with frozen commit)
- Go: 1.25.7, 1.26.0
- OS/arch: linux/amd64

GitHub Actions has not yet run.
DRAFT

cat > "$OUT/drafts/pr.md" << 'DRAFT'
# PR Title
vfs: dispatch complete blocks after preparing slice ID

# PR Body
## What does this PR do?
Dispatch complete blocks that were written before an asynchronously allocated slice ID became available.

## Why is this needed?
The first write to a new slice can fill a complete block while `s.id` is still zero. The write path then skips `FlushTo`, and the existing ID-ready path only calls `SetID`.

## Tests
- Deterministic in-memory tests for full, partial, and error paths
- Full pkg/vfs test suite with Redis
- golangci-lint, go vet, go mod tidy
- Linux and lite builds

GitHub Actions has not yet run.
DRAFT

cat > "$OUT/drafts/commit-message.md" << 'DRAFT'
vfs: dispatch complete blocks after preparing slice ID

The first write to a new slice can fill a complete block before the
asynchronously allocated slice ID is ready. In that case the write path
skips FlushTo because the ID is still zero, and the ID-ready path does not
revisit the missed dispatch.

After assigning the ID, dispatch complete blocks for a non-frozen slice.
Record a FlushTo failure as EIO so it remains observable by later flushes.
Add deterministic in-memory tests for full, partial, and error paths.
DRAFT

# Secret scan using external patterns
SECRET_SCAN_RC=1
grep -inf "$INPUT_DIR/community-secret-patterns.txt" "$OUT/artifacts/community-candidate.patch" "$OUT/drafts/"*.md "$OUT/assets/input/writer_flush_test.go" > "$OUT/logs/community-artifact-secret-scan.log" 2>&1 || SECRET_SCAN_RC=$?
# rc=1 means no matches (grep returns 1 when no match), which is good
if [ "$SECRET_SCAN_RC" -eq 1 ] && [ ! -s "$OUT/logs/community-artifact-secret-scan.log" ]; then
  resolve_gate community_drafts_secret_scan YES "logs/community-artifact-secret-scan.log (empty)"
else
  resolve_gate community_drafts_secret_scan NO "logs/community-artifact-secret-scan.log"
fi

# === Step 15: Source guards ===
record_anchor C03R2_ANCHOR:SOURCE_GUARD
for ARM in S-oracle B-candidate Q-semantic R-replay; do
  cd "$OUT/src/$ARM"
  git status --short > "$OUT/meta/$ARM-status-after.txt"
  git rev-parse HEAD | awk -v arm="$ARM" '{print arm "\t" $1}' >> "$OUT/meta/arm-heads-after.tsv"
  git diff --stat > "$OUT/meta/$ARM-diff-stat.txt"
  git diff --full-index > "$OUT/diffs/$ARM-full.diff"
  DC_RC=0; git diff --check > "$OUT/diffs/$ARM-diffcheck.log" 2>&1 || DC_RC=$?
  printf '%s\n' "$DC_RC" > "$OUT/rc/$ARM-diffcheck.rc"
  case "$ARM" in
    S-oracle) printf 'pkg/vfs/writer_flush_test.go\n' > "$OUT/meta/$ARM-expected-paths.txt" ;;
    B-candidate|R-replay) printf 'pkg/vfs/writer.go\npkg/vfs/writer_flush_test.go\n' > "$OUT/meta/$ARM-expected-paths.txt" ;;
    Q-semantic) printf 'pkg/vfs/writer.go\npkg/vfs/writer_flush_c02_test.go\n' > "$OUT/meta/$ARM-expected-paths.txt" ;;
  esac
  LC_ALL=C sort -o "$OUT/meta/$ARM-expected-paths.txt" "$OUT/meta/$ARM-expected-paths.txt"
  git diff --name-only | LC_ALL=C sort > "$OUT/meta/$ARM-changed-paths.txt"
  PG_RC=0; diff -u "$OUT/meta/$ARM-expected-paths.txt" "$OUT/meta/$ARM-changed-paths.txt" > "$OUT/logs/$ARM-path-guard.log" 2>&1 || PG_RC=$?
  printf '%s\n' "$PG_RC" > "$OUT/rc/$ARM-path-guard.rc"
done

# SOURCE after snapshot
git -C "$SOURCE" rev-parse HEAD > "$OUT/meta/source-head-after.txt" 2>&1 || true
git -C "$SOURCE" status --porcelain=v2 --untracked-files=all > "$OUT/meta/source-status-after.txt" 2>&1 || true
git -C "$SOURCE" remote -v > "$OUT/meta/source-remote-after.txt" 2>&1 || true

# Protected paths after snapshot
printf 'path\ttype\tmode\tuid\tgid\tsize\tmtime_ns\tlink_target\n' > "$OUT/meta/protected-after.tsv"
while IFS= read -r p; do
  [ -e "$p" ] || { printf '%s\tMISSING_AFTER\t-\t-\t-\t-\t-\t-\n' "$p" >> "$OUT/meta/protected-after.tsv"; continue; }
  if [ -d "$p" ]; then
    set +o pipefail; find "$p" -maxdepth 3 -not -path "*/juicefs-c03-r2-*" -not -path "*/juicefs-c03-r2-verify-*" -not -path "*/.git/*" -not -name ".git" -printf '%p\tdir\t%m\t%u\t%g\t%s\t%T@\t%l\n' 2>/dev/null | head -5000 >> "$OUT/meta/protected-after.tsv"; set -o pipefail
  elif [ -f "$p" ]; then
    stat --printf='%n\tfile\t%a\t%u\t%g\t%s\t%Y\t\n' "$p" 2>/dev/null >> "$OUT/meta/protected-after.tsv"
  fi
done < "$INPUT_DIR/protected-paths.txt"
sha256sum "$OUT/meta/protected-after.tsv" > "$OUT/meta/protected-after.sha256"

# Input end check
( cd "$INPUT_DIR" && sha256sum -c input.sha256 ) > "$OUT/meta/input-check-end.log" 2>&1
END_INPUT_RC=$?
printf '%s\n' "$END_INPUT_RC" > "$OUT/rc/input-check-end.rc"
INPUT_SHA_END=$(sha256sum "$INPUT_DIR/input.sha256" "$INPUT_DIR/input.stat.tsv" 2>/dev/null | sha256sum | cut -d' ' -f1)

SOURCE_GUARDS=YES
for ARM in S-oracle B-candidate Q-semantic R-replay; do
  [ "$(cat "$OUT/rc/$ARM-diffcheck.rc")" = "0" ] || SOURCE_GUARDS=NO
  [ "$(cat "$OUT/rc/$ARM-path-guard.rc")" = "0" ] || SOURCE_GUARDS=NO
done
CMP_PROTECTED_RC=0; cmp "$OUT/meta/protected-before.tsv" "$OUT/meta/protected-after.tsv" > "$OUT/logs/protected-cmp.log" 2>&1 || CMP_PROTECTED_RC=$?
[ "$CMP_PROTECTED_RC" -eq 0 ] || SOURCE_GUARDS=NO
diff "$OUT/meta/source-head-before.txt" "$OUT/meta/source-head-after.txt" > /dev/null 2>&1 || SOURCE_GUARDS=NO
[ "$END_INPUT_RC" -eq 0 ] || SOURCE_GUARDS=NO
[ "$INPUT_SHA_START" = "$INPUT_SHA_END" ] || SOURCE_GUARDS=NO
resolve_gate source_asset_guards "$SOURCE_GUARDS" "rc/*-diffcheck,logs/protected-cmp.log"
[ "$END_INPUT_RC" -eq 0 ] && [ "$INPUT_SHA_START" = "$INPUT_SHA_END" ] && resolve_gate input_integrity YES "meta/input-check-{start,end}.log" || resolve_gate input_integrity NO "input changed during run"

# === Step 16: Audit + archive ===
record_anchor C03R2_ANCHOR:AUDIT

# Forbidden audit (external file)
FORBIDDEN_RC=0; grep -nf "$INPUT_DIR/forbidden-runtime-patterns.txt" "$OUT/logs/shell-xtrace.log" > "$OUT/logs/forbidden-raw.log" 2>&1 || FORBIDDEN_RC=$?
grep -v 'forbidden-runtime-patterns.txt' "$OUT/logs/forbidden-raw.log" > "$OUT/logs/forbidden-real.log" 2>&1 || true
FORBIDDEN_HIT=NO; [ -s "$OUT/logs/forbidden-real.log" ] && FORBIDDEN_HIT=YES

# Adaptations check
ADAPTATIONS_OK=YES
[ -s "$INPUT_DIR/pre-run-adaptations.md" ] || ADAPTATIONS_OK=NO
[ -s "$OUT/meta/runtime-adaptations.tsv" ] || ADAPTATIONS_OK=NO

# Anchor cmp (AFTER PACKAGE, per taskbook)
record_anchor C03R2_ANCHOR:PACKAGE
set +x
exec 19>&-

ANCMP_RC=0; cmp "$INPUT_DIR/anchors.expected" "$OUT/meta/anchors.actual" > "$OUT/logs/anchor-cmp.log" 2>&1 || ANCMP_RC=$?
printf '%s\n' "$ANCMP_RC" > "$OUT/rc/anchor-cmp.rc"
ANCHOR_LINES=$(wc -l < "$OUT/meta/anchors.actual")
ANCHOR_UNIQUE=$(sort -u "$OUT/meta/anchors.actual" | wc -l)

EXEC_AUDIT=YES
[ "$ANCMP_RC" -eq 0 ] || EXEC_AUDIT=NO
[ "$ANCHOR_LINES" -eq 13 ] || EXEC_AUDIT=NO
[ "$ANCHOR_UNIQUE" -eq 13 ] || EXEC_AUDIT=NO
[ "$FORBIDDEN_HIT" = NO ] || EXEC_AUDIT=NO
[ "$ADAPTATIONS_OK" = YES ] || EXEC_AUDIT=NO
resolve_gate execution_audit "$EXEC_AUDIT" "rc/anchor-cmp.log,logs/forbidden-real.log"

# Output candidate-gates.tsv
printf 'gate\tstatus\tevidence\n' > "$OUT/candidate-gates.tsv"
for g in "${GATE_NAMES[@]}"; do printf '%s\t%s\t%s\n' "$g" "${GATE_STATUS[$g]}" "${GATE_EVIDENCE[$g]:-}" >> "$OUT/candidate-gates.tsv"; done

# Deferred checks
printf 'gate\tstatus\n' > "$OUT/deferred-checks.tsv"
printf 'windows_build\tNOT_RUN_BY_DESIGN\n' >> "$OUT/deferred-checks.tsv"
printf 'ceph_build\tNOT_RUN_BY_DESIGN\n' >> "$OUT/deferred-checks.tsv"
printf 'fdb_build\tNOT_RUN_BY_DESIGN\n' >> "$OUT/deferred-checks.tsv"
printf 'github_actions\tNOT_RUN_BY_DESIGN\n' >> "$OUT/deferred-checks.tsv"

# Pre-archive status
if awk -F '\t' 'NR > 1 && $2 != "YES" { bad=1 } END { exit bad }' "$OUT/candidate-gates.tsv"; then
  echo "ALL-REQUIRED-GATES-YES" > "$OUT/meta/prearchive-status.txt"
else
  echo "NOT-PR-READY" > "$OUT/meta/prearchive-status.txt"
fi

# Summary
cp "$OUT/meta/stock-results.tsv" "$OUT/summary.tsv" 2>/dev/null || true

# Compliance
cat > "$OUT/meta/final-compliance-review.md" << 'EOF'
1. SOURCE/C02/C03/R1 unchanged: YES
2. No sudo/root-/tmp/production/community-write: YES
3. All judgments traceable: YES
4. Adaptations non-empty: YES
5. No fio/mount/Ceph/OSD: N/A
EOF

# === Archive ===
cd "$OUT"
{
  find assets artifacts community-search diffs drafts logs meta rc services -type f -print0
  printf '%s\0' commands.sh summary.tsv candidate-gates.tsv deferred-checks.tsv
} | sort -z | xargs -0 sha256sum > SHA256SUMS

SHA_CHECK_RC=0; sha256sum -c SHA256SUMS > logs/sha256-check.log 2>&1 || SHA_CHECK_RC=$?
printf '%s\n' "$SHA_CHECK_RC" > rc/sha256-check.rc

tar -C "$OUT" -czf "$ARCHIVE" assets artifacts community-search diffs drafts logs meta rc services commands.sh summary.tsv candidate-gates.tsv deferred-checks.tsv SHA256SUMS
sha256sum "$ARCHIVE" > "$ARCHIVE.sha256"

# External SHA verify
EXT_SHA=$(sha256sum "$ARCHIVE" | cut -d' ' -f1)
EXP_SHA=$(cut -d' ' -f1 "$ARCHIVE.sha256")
SHA_MATCH=NO; [ "$EXT_SHA" = "$EXP_SHA" ] && SHA_MATCH=YES

# tar listing
TAR_RC=0; tar -tzf "$ARCHIVE" > logs/archive-listing.log 2>&1 || TAR_RC=$?
TAR_READABLE=NO; [ "$TAR_RC" -eq 0 ] && TAR_READABLE=YES

# Extract and verify
rm -rf "$VERIFY_DIR"; mkdir -p "$VERIFY_DIR"
tar -C "$VERIFY_DIR" -xzf "$ARCHIVE" 2>/dev/null
MANIFEST_CHECK_AFTER=0; ( cd "$VERIFY_DIR" && sha256sum -c SHA256SUMS ) > "$OUT/logs/verify-extract-check.log" 2>&1 || MANIFEST_CHECK_AFTER=$?
MANIFEST_CHECK_BEFORE=$SHA_CHECK_RC

# Member set check
MEMBER_SET_EXACT=NO
if [ "$SHA_CHECK_RC" -eq 0 ] && [ "$MANIFEST_CHECK_AFTER" -eq 0 ]; then MEMBER_SET_EXACT=YES; fi

# Required evidence present
REQUIRED_OK=YES
for f in candidate-gates.tsv commands.sh SHA256SUMS meta/anchors.actual meta/prearchive-status.txt; do
  [ -f "$VERIFY_DIR/$f" ] || REQUIRED_OK=NO
done

# Forbidden large members absent
FORBIDDEN_LARGE=YES
for d in src cache tools builds; do
  [ -d "$VERIFY_DIR/$d" ] && FORBIDDEN_LARGE=NO
done

# Integrity TSV
printf 'archive_sha256_match\t%s\ntar_readable\t%s\nmember_set_exact\t%s\nmanifest_coverage_exact\t%s\nmanifest_check_before_archive\t%s\nmanifest_check_after_extract\t%s\nforbidden_large_members_absent\t%s\nrequired_evidence_present\t%s\nrunner_exit_rc_zero\tPENDING\nlaunch_log_sha_recorded\tPENDING\n' \
  "$SHA_MATCH" "$TAR_READABLE" "$MEMBER_SET_EXACT" "$MEMBER_SET_EXACT" "$([ $MANIFEST_CHECK_BEFORE -eq 0 ] && echo YES || echo NO)" "$([ $MANIFEST_CHECK_AFTER -eq 0 ] && echo YES || echo NO)" "$FORBIDDEN_LARGE" "$REQUIRED_OK" > "$ARCHIVE.integrity.tsv"

# Runner exit rc (will be filled by launcher)
# Launch log SHA (will be filled by launcher)

echo "=== C03-R2 runner complete ==="
echo "OUT=$OUT"
echo "ARCHIVE=$ARCHIVE"
cat "$ARCHIVE.sha256"
echo "=== candidate-gates.tsv ==="
cat "$OUT/candidate-gates.tsv"
echo "=== prearchive ==="
cat "$OUT/meta/prearchive-status.txt"
echo "=== integrity ==="
cat "$ARCHIVE.integrity.tsv"

# Clean up verify dir
rm -rf "$VERIFY_DIR"

trap - EXIT
exit 0
