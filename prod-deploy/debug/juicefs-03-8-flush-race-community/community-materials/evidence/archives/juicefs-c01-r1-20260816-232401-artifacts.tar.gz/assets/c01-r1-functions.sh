#!/bin/bash
# C01-R1 test matrix functions - sourced into execution shell
# DO NOT execute directly

BASELINE_RE='^(TestSmode|TestEntryString|TestError|TestVFSIO)$'

run_zero_test() {
  local tool_label=$1
  local toolchain=$2
  local build_cache=$3
  local arm=$4
  local test_id=$5
  shift 5

  local log_rel=logs/$tool_label-$arm-$test_id.log
  local log_abs=$OUT/$log_rel

  (
    cd "$OUT/src/$arm" || exit 98
    env GOTOOLCHAIN="$toolchain" GOCACHE="$build_cache" GOFLAGS=-mod=readonly \
      GOPROXY=https://goproxy.cn,direct \
      GOMODCACHE="$OUT/cache/go-mod" \
      GOTMPDIR="$OUT/cache/go-tmp" \
      go test "$@"
  ) > "$log_abs" 2>&1
  local rc=$?
  local matched=NO
  test "$rc" -eq 0 && matched=YES

  printf '%s\n' "$rc" > "$OUT/rc/$tool_label-$arm-$test_id.rc"
  printf '%s\t%s\t%s\t%s\t0\t%s\t%s\n' \
    "$tool_label" "$arm" "$test_id" "$rc" "$log_rel" "$matched" \
    >> "$OUT/meta/test-results.raw.tsv"
}

run_stock_repro() {
  local tool_label=$1
  local toolchain=$2
  local build_cache=$3
  local details=$OUT/meta/$tool_label-S-stock-positive-repeat10.tsv
  local aggregate=0

  printf 'iteration\trc\tmarker_count\ttest_fail_count\tforbidden_error\texpectation_matched\tlog\n' \
    > "$details"

  for iteration in 01 02 03 04 05 06 07 08 09 10; do
    local log_rel=logs/$tool_label-S-stock-positive-$iteration.log
    local log_abs=$OUT/$log_rel

    (
      cd "$OUT/src/S-stock" || exit 98
      env GOTOOLCHAIN="$toolchain" GOCACHE="$build_cache" GOFLAGS=-mod=readonly \
        GOPROXY=https://goproxy.cn,direct \
        GOMODCACHE="$OUT/cache/go-mod" \
        GOTMPDIR="$OUT/cache/go-tmp" \
        go test ./pkg/vfs \
          -run '^TestFullBlockWriteIsDispatchedWhenSliceIDBecomesReady$' \
          -count=1 -v -timeout=2m
    ) > "$log_abs" 2>&1
    local rc=$?
    local marker_count
    marker_count=$(grep -c 'C01_MISSED_DISPATCH' "$log_abs" || true)
    local test_fail_count
    test_fail_count=$(grep -c -- \
      '--- FAIL: TestFullBlockWriteIsDispatchedWhenSliceIDBecomesReady' \
      "$log_abs" || true)
    local forbidden_error=NO
    if grep -Eq '\[build failed\]|panic:|fatal error:|test timed out|DATA RACE' \
      "$log_abs"; then
      forbidden_error=YES
    fi
    local matched=NO

    if test "$rc" -ne 0 \
      && test "$marker_count" -eq 1 \
      && test "$test_fail_count" -eq 1 \
      && test "$forbidden_error" = NO; then
      matched=YES
    else
      aggregate=1
    fi

    printf '%s\n' "$rc" \
      > "$OUT/rc/$tool_label-S-stock-positive-$iteration.rc"
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' \
      "$iteration" "$rc" "$marker_count" "$test_fail_count" \
      "$forbidden_error" "$matched" "$log_rel" \
      >> "$details"
  done

  printf '%s\n' "$aggregate" \
    > "$OUT/rc/$tool_label-S-stock-positive-repeat10-expectation.rc"
  local matched=NO
  test "$aggregate" -eq 0 && matched=YES
  printf '%s\tS-stock\tpositive-repeat10-expectation\t%s\t0\t%s\t%s\n' \
    "$tool_label" "$aggregate" \
    "meta/$tool_label-S-stock-positive-repeat10.tsv" "$matched" \
    >> "$OUT/meta/test-results.raw.tsv"
}

run_candidate_matrix() {
  local tool_label=$1
  local toolchain=$2
  local build_cache=$3

  for ARM in A-sync B-async-catchup; do
    run_zero_test "$tool_label" "$toolchain" "$build_cache" \
      "$ARM" positive \
      ./pkg/vfs \
      -run '^TestFullBlockWriteIsDispatchedWhenSliceIDBecomesReady$' \
      -count=1 -v -timeout=2m

    run_zero_test "$tool_label" "$toolchain" "$build_cache" \
      "$ARM" negative \
      ./pkg/vfs \
      -run '^TestPartialBlockIsNotDispatchedWhenSliceIDBecomesReady$' \
      -count=1 -v -timeout=2m

    run_zero_test "$tool_label" "$toolchain" "$build_cache" \
      "$ARM" targeted-count100 \
      ./pkg/vfs \
      -run '^(TestFullBlockWriteIsDispatchedWhenSliceIDBecomesReady|TestPartialBlockIsNotDispatchedWhenSliceIDBecomesReady)$' \
      -count=100 -v -timeout=10m

    run_zero_test "$tool_label" "$toolchain" "$build_cache" \
      "$ARM" memory-regression \
      ./pkg/vfs -run "$BASELINE_RE" -count=1 -v -timeout=10m

    run_zero_test "$tool_label" "$toolchain" "$build_cache" \
      "$ARM" race-count20 \
      -race ./pkg/vfs \
      -run '^(TestFullBlockWriteIsDispatchedWhenSliceIDBecomesReady|TestPartialBlockIsNotDispatchedWhenSliceIDBecomesReady)$' \
      -count=20 -v -timeout=10m
  done
}

gate_candidate_matrix() {
  local tool_label=$1
  local bad=0

  for ARM in A-sync B-async-catchup; do
    for TEST_ID in positive negative targeted-count100 memory-regression race-count20; do
      local rc_file=$OUT/rc/$tool_label-$ARM-$TEST_ID.rc
      if ! test -f "$rc_file" || ! test "$(cat "$rc_file")" -eq 0; then
        bad=1
      fi
    done

    if grep -q 'DATA RACE' \
      "$OUT/logs/$tool_label-$ARM-race-count20.log"; then
      bad=1
    fi

    if ! test "$(grep -c -- '--- PASS: TestFullBlockWriteIsDispatchedWhenSliceIDBecomesReady' \
      "$OUT/logs/$tool_label-$ARM-positive.log" || true)" -eq 1; then
      bad=1
    fi
    if ! test "$(grep -c -- '--- PASS: TestPartialBlockIsNotDispatchedWhenSliceIDBecomesReady' \
      "$OUT/logs/$tool_label-$ARM-negative.log" || true)" -eq 1; then
      bad=1
    fi
    if ! test "$(grep -c -- '--- PASS: TestFullBlockWriteIsDispatchedWhenSliceIDBecomesReady' \
      "$OUT/logs/$tool_label-$ARM-targeted-count100.log" || true)" -eq 100; then
      bad=1
    fi
    if ! test "$(grep -c -- '--- PASS: TestPartialBlockIsNotDispatchedWhenSliceIDBecomesReady' \
      "$OUT/logs/$tool_label-$ARM-targeted-count100.log" || true)" -eq 100; then
      bad=1
    fi
    if ! test "$(grep -c -- '--- PASS: TestFullBlockWriteIsDispatchedWhenSliceIDBecomesReady' \
      "$OUT/logs/$tool_label-$ARM-race-count20.log" || true)" -eq 20; then
      bad=1
    fi
    if ! test "$(grep -c -- '--- PASS: TestPartialBlockIsNotDispatchedWhenSliceIDBecomesReady' \
      "$OUT/logs/$tool_label-$ARM-race-count20.log" || true)" -eq 20; then
      bad=1
    fi
    for TEST_NAME in TestSmode TestEntryString TestError TestVFSIO; do
      if ! test "$(grep -c -- "--- PASS: $TEST_NAME" \
        "$OUT/logs/$tool_label-$ARM-memory-regression.log" || true)" -eq 1; then
        bad=1
      fi
    done
  done

  printf '%s\n' "$bad" \
    > "$OUT/rc/$tool_label-candidate-matrix-expectation.rc"
  local matched=NO
  test "$bad" -eq 0 && matched=YES
  printf '%s\tmatrix\tcandidate-matrix-expectation\t%s\t0\t%s\t%s\n' \
    "$tool_label" "$bad" \
    "rc/$tool_label-candidate-matrix-expectation.rc" "$matched" \
    >> "$OUT/meta/test-results.raw.tsv"
  return "$bad"
}
